# XITERAX Neo-Brutalism V4

## UI changes
- Bug selector is a dedicated two-page Number/Group screen.
- Bug Number uses all payloads except entries containing `GB` or `BAN GB`.
- Bug Group uses only payloads containing `GB` or `BAN GB`.
- Target field is placed before the large payload selector.
- Large payload cards use the same flat Neo-Brutalism system.
- Removed red/yellow visual accents from the new UI; palette is white/black/gray/orange/blue.
- Added subtle flat dot/diagonal texture to UI cards; no gradients or glow.
- Added functional profile and menu actions to Dashboard, WhatsApp and Tools headers.
- Tools remains limited to AI, COMIC and IQC.
- Landing page is independent from tool/comic content and uses the XITERAX banner.
- Boot/intro was redesigned to the same visual language.
- Profile page was restyled to match the same visual language.
- Existing API send flow, role checks, sender checks and tool routes are retained.
