from pathlib import Path
root=Path('/tmp/rework6/lib')

def scan_call(s, start, names):
    p=start
    while p<len(s) and s[p].isspace(): p+=1
    if s.startswith('const ',p): p+=6
    name=next((n for n in names if s.startswith(n,p)),None)
    if not name:return None
    op=s.find('(',p+len(name))
    if op<0:return None
    depth=0; j=op; q=None; esc=False
    while j<len(s):
        c=s[j]
        if q:
            if esc:esc=False
            elif c=='\\':esc=True
            elif c==q:q=None
        else:
            if c in "'\"":q=c
            elif c=='(':depth+=1
            elif c==')':
                depth-=1
                if depth==0:return j+1
        j+=1
    return None

def flat_gradient_props(s):
    pos=0; out=[]
    while True:
        idx=s.find('gradient:',pos)
        if idx<0: out.append(s[pos:]); break
        out.append(s[pos:idx])
        end=scan_call(s,idx+len('gradient:'),('LinearGradient','RadialGradient'))
        if end is not None:
            out.append('color: XiteraxColors.surfaceRaised')
            pos=end
        else:
            # named gradient values / conditionals
            e=s.find('\n',idx)
            if e<0:e=len(s)
            line=s[idx:e]
            if 'redGradient' in line or 'primaryGradient' in line or 'secondaryGradient' in line or 'iconGradient' in line:
                out.append('color: XiteraxColors.yellow')
                pos=e
            else:
                out.append(s[idx:e]);pos=e
    return ''.join(out)

def flat_getters(s):
    pos=0; out=[]
    while True:
        idx=min([x for x in [s.find('LinearGradient get ',pos), s.find('final LinearGradient ',pos)] if x>=0], default=-1)
        if idx<0: out.append(s[pos:]); break
        out.append(s[pos:idx])
        if s.startswith('LinearGradient get ',idx):
            a=idx+len('LinearGradient get '); b=s.find(' ',a); name=s[a:b]
            arrow=s.find('=>',b); end=scan_call(s,arrow+2,('LinearGradient','RadialGradient')) if arrow>=0 else None
            if end:
                out.append('Color get '+name+' => XiteraxColors.yellow;');pos=end;continue
        if s.startswith('final LinearGradient ',idx):
            a=idx+len('final LinearGradient '); b=s.find(' ',a); name=s[a:b]
            eq=s.find('=',b); end=scan_call(s,eq+1,('LinearGradient','RadialGradient')) if eq>=0 else None
            if end:
                out.append('final Color '+name+' = XiteraxColors.yellow;');pos=end;continue
        out.append(s[idx]);pos=idx+1
    return ''.join(out)

for p in root.rglob('*.dart'):
    s=p.read_text()
    s=flat_gradient_props(s)
    s=flat_getters(s)
    s=s.replace('gradient: isActive ? primaryGradient : null,','color: isActive ? XiteraxColors.yellow : null,')
    s=s.replace('gradient: currentPage == page ? redGradient : null,','color: currentPage == page ? XiteraxColors.yellow : null,')
    s=s.replace('gradient: isKilling ? null : redGradient,','color: isKilling ? null : XiteraxColors.yellow,')
    s=s.replace('Sender pribadi otomatis masuk ke pool global setelah terhubung.', 'Kelola sender pribadi dan global dari satu tempat.')
    s=s.replace("isGlobal ? 'GLOBAL • otomatis' : 'PRIVATE • ${widget.username}'", "isGlobal ? 'GLOBAL' : 'PRIVATE • ${widget.username}'")
    p.write_text(s)

p=root/'xiterax_theme.dart';s=p.read_text().replace('const CustomPaint(painter: _NeoPatternPainter()),','const SizedBox.shrink()');p.write_text(s)
