# XITERAX Base — Auto Global Sender

Perubahan terbaru:
- Global Sender tetap otomatis dari sender pribadi setelah terhubung.
- Pemilik sender tidak ditampilkan di UI maupun response registry client.
- Limit harian/daily quota pengiriman Bug/Global Sender dihapus.
- Cooldown anti-spam yang sudah ada tetap dipertahankan agar fungsi existing tidak rusak.
- Tidak ada menu Add Global manual.
