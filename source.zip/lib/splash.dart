import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:audioplayers/audioplayers.dart';
import 'dashboard_page.dart';
import 'xiterax_theme.dart';

class SplashScreen extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const SplashScreen({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
    required this.listDoos,
    required this.news,
  });

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late final VideoPlayerController _videoController;
  late final AnimationController _fadeController;
  final AudioPlayer _audioPlayer = AudioPlayer();
  bool _fadeOutStarted = false;
  bool _navigated = false;

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 850),
    );
    _initializeMedia();
  }

  Future<void> _initializeMedia() async {
    _videoController = VideoPlayerController.asset('assets/videos/xiterax_splash.mp4');
    try {
      await _videoController.initialize();
      if (!mounted) return;
      setState(() {});
      await _videoController.setLooping(false);
      await _videoController.play();

      await _audioPlayer.setReleaseMode(ReleaseMode.loop);
      await _audioPlayer.setVolume(0.45);
      await _audioPlayer.play(AssetSource('audio/xiterax_background.mp3'));

      _videoController.addListener(_videoListener);
    } catch (_) {
      if (mounted) _navigateToDashboard();
    }
  }

  void _videoListener() {
    if (!_videoController.value.isInitialized || _navigated) return;
    final position = _videoController.value.position;
    final duration = _videoController.value.duration;
    if (duration.inMilliseconds <= 0) return;

    if (position >= duration - const Duration(milliseconds: 850) && !_fadeOutStarted) {
      _fadeOutStarted = true;
      _fadeController.forward();
    }
    if (position >= duration) _navigateToDashboard();
  }

  void _navigateToDashboard() {
    if (_navigated || !mounted) return;
    _navigated = true;
    _audioPlayer.stop();
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (_) => DashboardPage(
          username: widget.username,
          password: widget.password,
          role: widget.role,
          expiredDate: widget.expiredDate,
          sessionKey: widget.sessionKey,
          listBug: widget.listBug,
          listDoos: widget.listDoos,
          news: widget.news,
        ),
      ),
    );
  }

  void _skipSplash() {
    if (_videoController.value.isInitialized) {
      _videoController.pause();
    }
    _navigateToDashboard();
  }

  @override
  void dispose() {
    if (_videoController.value.isInitialized) {
      _videoController.removeListener(_videoListener);
    }
    _videoController.dispose();
    _audioPlayer.dispose();
    _fadeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          if (_videoController.value.isInitialized)
            FittedBox(
              fit: BoxFit.cover,
              child: SizedBox(
                width: _videoController.value.size.width,
                height: _videoController.value.size.height,
                child: VideoPlayer(_videoController),
              ),
            )
          else
            const Center(
              child: CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(XiteraxColors.orange),
              ),
            ),
          Container(color: Colors.black.withValues(alpha: 0.18)),
          Positioned(
            top: 52,
            right: 18,
            child: GestureDetector(
              onTap: _skipSplash,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 9),
                decoration: BoxDecoration(
                  color: Colors.black.withValues(alpha: 0.48),
                  borderRadius: BorderRadius.circular(30),
                  border: Border.all(color: XiteraxColors.orange.withValues(alpha: 0.72)),
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.arrow_forward_rounded, color: Colors.white, size: 17),
                    SizedBox(width: 6),
                    Text(
                      'SKIP',
                      style: TextStyle(
                        color: XiteraxColors.orange,
                        fontSize: 11,
                        fontWeight: FontWeight.w800,
                        fontFamily: 'Baloo2',
                        letterSpacing: 1.2,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Positioned(
            left: 24,
            right: 24,
            bottom: 54,
            child: Column(
              children: [
                const Text(
                  'XITERAX SYSTEM',
                  style: TextStyle(
                    color: Colors.white,
                    fontFamily: 'Baloo2',
                    fontSize: 25,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 3.5,
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  'SECURE ENVIRONMENT',
                  style: TextStyle(
                    color: Color(0xFFD6DCE2),
                    fontFamily: 'Baloo2',
                    fontSize: 10,
                    letterSpacing: 2,
                  ),
                ),
                const SizedBox(height: 16),
                ClipRRect(
                  borderRadius: BorderRadius.circular(99),
                  child: const LinearProgressIndicator(
                    minHeight: 3,
                    backgroundColor: Color(0x55333333),
                    valueColor: AlwaysStoppedAnimation(XiteraxColors.orange),
                  ),
                ),
              ],
            ),
          ),
          if (_fadeOutStarted)
            FadeTransition(
              opacity: _fadeController.drive(Tween(begin: 0.0, end: 1.0)),
              child: const ColoredBox(color: Colors.black),
            ),
        ],
      ),
    );
  }
}
