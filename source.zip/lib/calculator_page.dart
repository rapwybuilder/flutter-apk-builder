import 'package:flutter/material.dart';
import 'xiterax_theme.dart';

class CalculatorPage extends StatefulWidget {
  const CalculatorPage({super.key});
  @override State<CalculatorPage> createState() => _CalculatorPageState();
}

class _CalculatorPageState extends State<CalculatorPage> {
  String display = '0';
  String op = '';
  double? first;

  void tap(String v) {
    setState(() {
      if (v == 'C') { display = '0'; op = ''; first = null; return; }
      if ('0123456789.'.contains(v)) { display = display == '0' ? v : display + v; return; }
      if (v == '=') {
        final b = double.tryParse(display) ?? 0;
        if (first != null) {
          final a = first!;
          final r = op == '+' ? a + b : op == '-' ? a - b : op == '×' ? a * b : (b == 0 ? 0 : a / b);
          display = r.toStringAsFixed(r.truncateToDouble() == r ? 0 : 4);
          first = null; op = '';
        }
        return;
      }
      first = double.tryParse(display) ?? 0;
      op = v;
      display = '0';
    });
  }

  @override
  Widget build(BuildContext context) {
    const keys = ['C', '÷', '×', '-', '7', '8', '9', '+', '4', '5', '6', '0', '1', '2', '3', '='];
    return Scaffold(
      backgroundColor: XiteraxColors.background,
      appBar: AppBar(title: const Text('CALCULATOR XITERAX')),
      body: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(children: [
          XiteraxNeoCard(color: XiteraxColors.black, child: Align(alignment: Alignment.centerRight, child: Text(display, style: const TextStyle(color: Colors.white, fontSize: 34, fontWeight: FontWeight.w900)))),
          const SizedBox(height: 14),
          Expanded(child: GridView.builder(
            itemCount: keys.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 4, crossAxisSpacing: 9, mainAxisSpacing: 9),
            itemBuilder: (_, i) => ElevatedButton(
              onPressed: () => tap(keys[i]),
              style: ElevatedButton.styleFrom(backgroundColor: keys[i] == '=' ? XiteraxColors.orange : XiteraxColors.white, foregroundColor: XiteraxColors.black, side: const BorderSide(color: XiteraxColors.black, width: 2), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(13))),
              child: Text(keys[i], style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
            ),
          )),
        ]),
      ),
    );
  }
}
