import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'xiterax_theme.dart';

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});
  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> with SingleTickerProviderStateMixin {
  late final AnimationController _animationController;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(vsync: this, duration: const Duration(milliseconds: 700))..forward();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  Future<void> _openUrl(String url) async => launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: XiteraxColors.background,
      body: XiteraxBackground(
        imageAsset: 'assets/images/xiterax_background.jpg',
        child: SafeArea(
          child: FadeTransition(
            opacity: CurvedAnimation(parent: _animationController, curve: Curves.easeOut),
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(14, 14, 14, 30),
              child: Column(children: [
                _topBar(),
                const SizedBox(height: 14),
                _hero(),
                const SizedBox(height: 14),
                _status(),
                const SizedBox(height: 14),
                _accessPanel(),
                const SizedBox(height: 14),
                _miniFeatures(),
                const SizedBox(height: 14),
                _footer(),
              ]),
            ),
          ),
        ),
      ),
    );
  }

  Widget _topBar() => XiteraxNeoCard(padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 9), child: Row(children: [
    Container(width: 42, height: 42, decoration: BoxDecoration(color: XiteraxColors.black, border: Border.all(color: XiteraxColors.black, width: 2), borderRadius: BorderRadius.circular(12)), child: const Icon(Icons.bolt_rounded, color: XiteraxColors.white, size: 23)),
    const SizedBox(width: 10),
    const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('XITERAX', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, letterSpacing: 2)), Text('SECURE SYSTEM', style: TextStyle(fontSize: 8, fontWeight: FontWeight.w900, color: XiteraxColors.greyDark, letterSpacing: 1.2))])),
    Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 7), decoration: BoxDecoration(color: XiteraxColors.orange, border: Border.all(color: XiteraxColors.black, width: 2), borderRadius: BorderRadius.circular(10)), child: const Text('ONLINE', style: TextStyle(fontSize: 9, fontWeight: FontWeight.w900))),
  ]));

  Widget _hero() => XiteraxNeoCard(padding: EdgeInsets.zero, borderRadius: BorderRadius.circular(16), child: ClipRRect(borderRadius: BorderRadius.circular(14), child: Column(children: [
    SizedBox(height: 175, width: double.infinity, child: Stack(fit: StackFit.expand, children: [
      Image.asset('assets/images/xiterax_banner.jpg', fit: BoxFit.cover),
      const ColoredBox(color: Color(0x33000000)),
      Positioned(left: 16, right: 16, bottom: 16, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5), decoration: BoxDecoration(color: XiteraxColors.white, border: Border.all(color: XiteraxColors.black, width: 2), borderRadius: BorderRadius.circular(9)), child: const Text('WELCOME', style: TextStyle(fontSize: 8, fontWeight: FontWeight.w900))),
        const SizedBox(height: 8),
        const Text('XITERAX', style: TextStyle(color: XiteraxColors.white, fontSize: 30, fontWeight: FontWeight.w900, letterSpacing: 3)),
        const Text('SERVER • CONTROL • ACCESS', style: TextStyle(color: XiteraxColors.white, fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
      ])),
    ])),
    Padding(padding: const EdgeInsets.all(14), child: Row(children: [const Expanded(child: Text('Satu pintu untuk akses sistem XITERAX.', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w800))), Container(width: 36, height: 36, decoration: BoxDecoration(color: XiteraxColors.blue, border: Border.all(color: XiteraxColors.black, width: 2), shape: BoxShape.circle), child: const Icon(Icons.arrow_forward_rounded, color: XiteraxColors.white, size: 18))])),
  ])));

  Widget _status() => XiteraxNeoCard(child: Row(children: [Container(width: 48, height: 48, decoration: BoxDecoration(color: XiteraxColors.blue, border: Border.all(color: XiteraxColors.black, width: 2), shape: BoxShape.circle), child: const Icon(Icons.dns_rounded, color: XiteraxColors.white)), const SizedBox(width: 11), const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('SERVER READY', style: TextStyle(color: XiteraxColors.blue, fontSize: 16, fontWeight: FontWeight.w900)), SizedBox(height: 2), Text('Interface siap digunakan dari perangkat kamu.', style: TextStyle(fontSize: 10, color: XiteraxColors.greyDark, fontWeight: FontWeight.w700))])), Container(width: 11, height: 11, decoration: BoxDecoration(color: XiteraxColors.green, shape: BoxShape.circle, border: Border.all(color: XiteraxColors.black, width: 1)))]));

  Widget _accessPanel() => XiteraxNeoCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Row(children: [Icon(Icons.login_rounded), SizedBox(width: 8), Text('ACCESS PANEL', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900, letterSpacing: 1))]), const SizedBox(height: 8), const Text('Masuk untuk membuka dashboard dan sistem yang tersedia.', style: TextStyle(fontSize: 11, color: XiteraxColors.greyDark, fontWeight: FontWeight.w700, height: 1.35)), const SizedBox(height: 13), SizedBox(width: double.infinity, height: 55, child: ElevatedButton.icon(onPressed: () => Navigator.pushNamed(context, '/login'), icon: const Icon(Icons.arrow_forward_rounded), label: const Text('MASUK KE XITERAX'))), const SizedBox(height: 9), Row(children: [Expanded(child: OutlinedButton.icon(onPressed: () => _openUrl('https://t.me/rapwy'), icon: const Icon(Icons.shopping_bag_outlined), label: const Text('BELI AKSES'))), const SizedBox(width: 8), Expanded(child: OutlinedButton.icon(onPressed: () => _openUrl('https://t.me/rapwy'), icon: const Icon(Icons.support_agent_rounded), label: const Text('SUPPORT')))])]));

  Widget _miniFeatures() => Row(children: [
    _miniFeature(Icons.shield_rounded, 'SECURE', XiteraxColors.orange),
    const SizedBox(width: 8),
    _miniFeature(Icons.speed_rounded, 'FAST', XiteraxColors.blue),
    const SizedBox(width: 8),
    _miniFeature(Icons.phone_android_rounded, 'MOBILE', XiteraxColors.surfaceSoft),
  ]);

  Widget _miniFeature(IconData icon, String label, Color color) { final light = color == XiteraxColors.surfaceSoft; return Expanded(child: XiteraxNeoCard(padding: const EdgeInsets.symmetric(vertical: 13, horizontal: 5), color: color, child: Column(children: [Icon(icon, color: light ? XiteraxColors.black : XiteraxColors.white, size: 23), const SizedBox(height: 5), Text(label, style: TextStyle(color: light ? XiteraxColors.black : XiteraxColors.white, fontSize: 9, fontWeight: FontWeight.w900))]))); }

  Widget _footer() => XiteraxNeoCard(
        color: XiteraxColors.black,
        child: Column(
          children: [
            const Text('XITERAX', style: TextStyle(color: XiteraxColors.white, fontSize: 16, fontWeight: FontWeight.w900, letterSpacing: 2)),
            const SizedBox(height: 4),
            const Text('DESIGN BY RAPWY', style: TextStyle(color: XiteraxColors.surfaceRaised, fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
            const SizedBox(height: 11),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _social(Icons.send_rounded, 'Telegram', 'https://t.me/rapwy'),
                const SizedBox(width: 20),
                _social(Icons.music_note_rounded, 'TikTok', 'https://www.tiktok.com/@rapwy_'),
              ],
            ),
          ],
        ),
      );

  Widget _social(IconData icon, String label, String url) => GestureDetector(
        onTap: () => _openUrl(url),
        child: Column(
          children: [
            Container(
              width: 42,
              height: 42,
              decoration: BoxDecoration(color: XiteraxColors.white, border: Border.all(color: XiteraxColors.white, width: 2), borderRadius: BorderRadius.circular(11)),
              child: Icon(icon, color: XiteraxColors.black, size: 19),
            ),
            const SizedBox(height: 4),
            Text(label, style: const TextStyle(color: XiteraxColors.white, fontSize: 8, fontWeight: FontWeight.w900)),
          ],
        ),
      );

}
