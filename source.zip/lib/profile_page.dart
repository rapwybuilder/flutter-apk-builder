// profile_page.dart
import 'dart:io';
import 'package:flutter/material.dart';
import 'xiterax_theme.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'change_password_page.dart';

class ProfilePage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;

  const ProfilePage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
  });

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  File? _profileImage;
  final ImagePicker _picker = ImagePicker();

  // --- MODERN RED THEME (sama dengan dashboard) ---
  static const Color bgDark = Color(0xB3090A10);
  static const Color accentRed = XiteraxColors.orange;
  static const Color darkRed = Color(0xFF2B333D);
  static const Color softRed = Color(0xFFFF8A4C);
  static const Color primaryWhite = Color(0xFFFFFFFF);
  static const Color softGrey = Color(0xFFA8A29E);
  static const Color glassPrimary = Color(0x1AFFFFFF);
  static const Color glassSecondary = Color(0x0DFFFFFF);

  Color get redGradient => XiteraxColors.orange;

  @override
  void initState() {
    super.initState();
    _loadProfileImage();
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final imagePath = prefs.getString('profile_image_${widget.username}');
    if (imagePath != null && imagePath.isNotEmpty) {
      setState(() {
        _profileImage = File(imagePath);
      });
    }
  }

  String _censorText(String text, {bool isPassword = false}) {
    if (text.isEmpty) return "N/A";
    if (isPassword) {
      return "••••••••";
    }
    if (text.length <= 2) return "${text.substring(0, 1)}••";
    return "${text.substring(0, 2)}${'•' * (text.length - 2)}";
  }

  Future<void> _showImageSourceDialog() {
    return showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => Container(
        decoration: BoxDecoration(
          color: bgDark,
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(28),
            topRight: Radius.circular(28),
          ),
          border: Border.all(color: primaryWhite.withOpacity(0.08)),
        ),
        child: SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: glassPrimary,
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(28),
                    topRight: Radius.circular(28),
                  ),
                ),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: XiteraxColors.orange,
                        shape: BoxShape.circle,

                      ),
                      child: const Icon(Icons.camera_alt, color: primaryWhite, size: 22),
                    ),
                    const SizedBox(width: 14),
                    const Text(
                      "Pilih Sumber",
                      style: TextStyle(
                        color: primaryWhite,
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ),
              const Divider(color: Colors.white12, height: 1),
              ListTile(
                leading: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: accentRed.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Icon(Icons.camera_alt, color: accentRed, size: 20),
                ),
                title: const Text("Kamera", style: TextStyle(color: primaryWhite)),
                trailing: Icon(Icons.arrow_forward_ios, color: softGrey, size: 16),
                onTap: () {
                  Navigator.pop(context);
                  _pickImage(ImageSource.camera);
                },
              ),
              ListTile(
                leading: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: accentRed.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Icon(Icons.photo_library, color: accentRed, size: 20),
                ),
                title: const Text("Galeri", style: TextStyle(color: primaryWhite)),
                trailing: Icon(Icons.arrow_forward_ios, color: softGrey, size: 16),
                onTap: () {
                  Navigator.pop(context);
                  _pickImage(ImageSource.gallery);
                },
              ),
              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final XFile? pickedFile = await _picker.pickImage(
        source: source,
        imageQuality: 70,
      );

      if (pickedFile != null) {
        final File imageFile = File(pickedFile.path);
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('profile_image_${widget.username}', imageFile.path);

        setState(() {
          _profileImage = imageFile;
        });
      }
    } catch (e) {
      print("Error picking image: $e");
    }
  }

  Future<void> _logout() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: XiteraxColors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
          side: const BorderSide(color: XiteraxColors.black, width: 2),
        ),
        title: const Text('LOGOUT?', style: TextStyle(fontWeight: FontWeight.w900)),
        content: const Text(
          'Sesi login di perangkat ini akan dihapus.',
          style: TextStyle(fontWeight: FontWeight.w600),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('BATAL'),
          ),
          ElevatedButton.icon(
            onPressed: () => Navigator.pop(dialogContext, true),
            icon: const Icon(Icons.logout_rounded),
            label: const Text('LOGOUT'),
          ),
        ],
      ),
    );

    if (confirmed != true || !mounted) return;

    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('username');
    await prefs.remove('password');
    await prefs.remove('key');

    if (!mounted) return;
    Navigator.of(context).pushNamedAndRemoveUntil('/login', (route) => false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: XiteraxColors.background,
      appBar: AppBar(
        title: const Text('MY PROFILE'),
        leading: IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.arrow_back_rounded)),
      ),
      body: XiteraxBackground(
        imageAsset: 'assets/images/xiterax_menu_background.jpg',
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(14, 10, 14, 28),
            child: Column(children: [
              XiteraxNeoCard(child: Column(children: [
                GestureDetector(
                  onTap: _showImageSourceDialog,
                  child: Stack(children: [
                    Container(width: 118, height: 118, decoration: BoxDecoration(color: XiteraxColors.orange, shape: BoxShape.circle, border: Border.all(color: XiteraxColors.black, width: 3), boxShadow: const [BoxShadow(color: XiteraxColors.black, offset: Offset(5, 6), blurRadius: 0)]), child: ClipOval(child: _profileImage != null ? Image.file(_profileImage!, fit: BoxFit.cover) : const Icon(FontAwesomeIcons.userAstronaut, size: 48, color: XiteraxColors.white))),
                    Positioned(right: 1, bottom: 2, child: Container(width: 36, height: 36, decoration: BoxDecoration(color: XiteraxColors.blue, shape: BoxShape.circle, border: Border.all(color: XiteraxColors.black, width: 2)), child: const Icon(Icons.camera_alt_rounded, color: XiteraxColors.white, size: 17))),
                  ]),
                ),
                const SizedBox(height: 13),
                Text(widget.username, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
                const SizedBox(height: 5),
                Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5), decoration: BoxDecoration(color: XiteraxColors.surfaceSoft, border: Border.all(color: XiteraxColors.black, width: 2), borderRadius: BorderRadius.circular(9)), child: Text(widget.role.toUpperCase(), style: const TextStyle(fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 1.1))),
              ])),
              const SizedBox(height: 12),
              _buildInfoCard(Icons.person_outline_rounded, 'USERNAME', _censorText(widget.username)),
              _buildInfoCard(Icons.lock_outline_rounded, 'PASSWORD', _censorText(widget.password, isPassword: true)),
              _buildInfoCard(Icons.verified_user_outlined, 'ROLE', widget.role.toUpperCase()),
              _buildInfoCard(Icons.calendar_today_outlined, 'EXPIRED DATE', widget.expiredDate),
              _buildInfoCard(Icons.vpn_key_rounded, 'SESSION KEY', widget.sessionKey.length > 12 ? '${widget.sessionKey.substring(0, 12)}...' : widget.sessionKey),
              const SizedBox(height: 7),
              SizedBox(width: double.infinity, height: 54, child: ElevatedButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ChangePasswordPage(username: widget.username, sessionKey: widget.sessionKey))), icon: const Icon(Icons.lock_reset_rounded), label: const Text('CHANGE PASSWORD'))),
              const SizedBox(height: 10),
              SizedBox(width: double.infinity, height: 54, child: OutlinedButton.icon(onPressed: _logout, icon: const Icon(Icons.logout_rounded), label: const Text('LOGOUT'))),
              const SizedBox(height: 14),
              const Text('XITERAX PROFILE • RAPWY', style: TextStyle(fontSize: 9, fontWeight: FontWeight.w900, color: XiteraxColors.greyDark, letterSpacing: 1.2)),
            ]),
          ),
        ),
      ),
    );
  }

  Widget _buildInfoCard(IconData icon, String label, String value) => Padding(
    padding: const EdgeInsets.only(bottom: 9),
    child: XiteraxNeoCard(
      padding: const EdgeInsets.all(11),
      child: Row(children: [
        Container(width: 42, height: 42, decoration: BoxDecoration(color: XiteraxColors.surfaceSoft, border: Border.all(color: XiteraxColors.black, width: 2), borderRadius: BorderRadius.circular(11)), child: Icon(icon, size: 20)),
        const SizedBox(width: 10),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(label, style: const TextStyle(fontSize: 8, fontWeight: FontWeight.w900, color: XiteraxColors.greyDark, letterSpacing: .8)), const SizedBox(height: 3), Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w900))])),
      ]),
    ),
  );
}
