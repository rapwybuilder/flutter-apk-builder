//JANGAN LU MALING
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:audioplayers/audioplayers.dart';
import 'xiterax_theme.dart';

class SpotifyPage extends StatefulWidget {
  const SpotifyPage({super.key});

  @override
  State<SpotifyPage> createState() => _SpotifyPageState();
}

class _SpotifyPageState extends State<SpotifyPage> {
  final TextEditingController _searchController = TextEditingController();
  final AudioPlayer _audioPlayer = AudioPlayer();
  bool _isLoading = false;
  bool _isPlaying = false;
  bool _hasSearchResult = false;
  Map<String, dynamic>? _trackData;
  Duration _duration = Duration.zero;
  Duration _position = Duration.zero;

  @override
  void initState() {
    super.initState();
    _audioPlayer.onPlayerStateChanged.listen((state) {
      setState(() {
        _isPlaying = state == PlayerState.playing;
      });
    });

    _audioPlayer.onDurationChanged.listen((duration) {
      setState(() {
        _duration = duration;
      });
    });

    _audioPlayer.onPositionChanged.listen((position) {
      setState(() {
        _position = position;
      });
    });
  }

  Future<void> _searchTrack() async {
    if (_searchController.text.isEmpty) return;

    setState(() {
      _isLoading = true;
      _hasSearchResult = false;
      _isPlaying = false;
      _position = Duration.zero;
      _duration = Duration.zero;
    });

    try {
      final response = await http.get(
        Uri.parse('https://api.deline.web.id/downloader/spotifyplay?q=${_searchController.text}'),
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['status'] == true) {
          setState(() {
            _trackData = data;
            _hasSearchResult = true;
          });
          _playTrack();
        } else {
          _showError('Track tidak ditemukan');
        }
      } else {
        _showError('Gagal menghubungi server');
      }
    } catch (e) {
      _showError('Error: $e');
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _playTrack() async {
    if (_trackData != null && _trackData!['result'] != null) {
      final url = _trackData!['result']['dlink'];
      await _audioPlayer.play(UrlSource(url));
    }
  }

  Future<void> _pauseTrack() async {
    await _audioPlayer.pause();
  }

  Future<void> _stopTrack() async {
    await _audioPlayer.stop();
    setState(() {
      _position = Duration.zero;
    });
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: Colors.red,
        content: Text(message),
      ),
    );
  }

  String _formatDuration(Duration duration) {
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    final minutes = duration.inMinutes.remainder(60);
    final seconds = duration.inSeconds.remainder(60);
    return '${twoDigits(minutes)}:${twoDigits(seconds)}';
  }

  String _formatTimeString(String timeStr) {
    try {
      final parts = timeStr.split(':');
      if (parts.length == 2) {
        final minutes = int.parse(parts[0]);
        final seconds = int.parse(parts[1]);
        return '${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}';
      }
      return timeStr;
    } catch (e) {
      return timeStr;
    }
  }

  @override
  void dispose() {
    _audioPlayer.dispose();
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final meta = _trackData?['result']?['metadata'];
    return Scaffold(
      backgroundColor: XiteraxColors.background,
      appBar: AppBar(title: const Text('SPOTIFY XITERAX')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(14, 8, 14, 28),
        children: [
          XiteraxNeoCard(color: XiteraxColors.orange, child: const Row(children: [Icon(Icons.music_note_rounded, size: 30), SizedBox(width: 10), Expanded(child: Text('SPOTIFY PLAY • SEARCH & PLAY', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)))])),
          const SizedBox(height: 12),
          Row(children: [Expanded(child: TextField(controller: _searchController, onSubmitted: (_) => _searchTrack(), decoration: const InputDecoration(prefixIcon: Icon(Icons.search_rounded), hintText: 'Judul lagu atau artis'))), const SizedBox(width: 8), SizedBox(width: 54, height: 54, child: ElevatedButton(onPressed: _isLoading ? null : _searchTrack, child: _isLoading ? const SizedBox(width: 19, height: 19, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.search_rounded)))]),
          const SizedBox(height: 12),
          if (meta != null) ...[
            XiteraxNeoCard(child: Column(children: [
              ClipRRect(borderRadius: BorderRadius.circular(13), child: Image.network('${meta['cover'] ?? ''}', height: 210, width: 210, fit: BoxFit.cover, errorBuilder: (_, __, ___) => Container(height: 210, width: 210, color: XiteraxColors.surfaceSoft, child: const Icon(Icons.music_note_rounded, size: 60)))),
              const SizedBox(height: 12), Text('${meta['title'] ?? 'Unknown'}', textAlign: TextAlign.center, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
              const SizedBox(height: 3), Text('${meta['artist'] ?? 'Unknown artist'}', style: const TextStyle(color: XiteraxColors.grey, fontWeight: FontWeight.w800)),
              const SizedBox(height: 14),
              Slider(value: _position.inSeconds.toDouble().clamp(0, _duration.inSeconds > 0 ? _duration.inSeconds.toDouble() : 1), min: 0, max: _duration.inSeconds > 0 ? _duration.inSeconds.toDouble() : 1, onChanged: (v) => _audioPlayer.seek(Duration(seconds: v.toInt())), activeColor: XiteraxColors.orange),
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(_formatDuration(_position), style: const TextStyle(fontWeight: FontWeight.w800)), Text(_formatDuration(_duration), style: const TextStyle(fontWeight: FontWeight.w800))]),
              const SizedBox(height: 8),
              Row(mainAxisAlignment: MainAxisAlignment.center, children: [IconButton(onPressed: _stopTrack, icon: const Icon(Icons.stop_circle_outlined, size: 34)), const SizedBox(width: 10), Container(decoration: BoxDecoration(color: XiteraxColors.black, border: Border.all(color: XiteraxColors.black, width: 2), shape: BoxShape.circle), child: IconButton(onPressed: _isPlaying ? _pauseTrack : _playTrack, icon: Icon(_isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded, color: Colors.white, size: 36))), const SizedBox(width: 10), IconButton(onPressed: _playTrack, icon: const Icon(Icons.replay_rounded, size: 30))])
            ])),
          ] else XiteraxNeoCard(color: XiteraxColors.surfaceSoft, child: const Column(children: [Icon(Icons.music_note_rounded, size: 60), SizedBox(height: 8), Text('Cari lagu favoritmu', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)), SizedBox(height: 4), Text('Hasil pencarian akan tampil di sini.', style: TextStyle(color: XiteraxColors.grey, fontWeight: FontWeight.w700))])),
        ],
      ),
    );
  }
}