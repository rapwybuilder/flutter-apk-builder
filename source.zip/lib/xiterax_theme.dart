import 'package:flutter/material.dart';

/// XITERAX Soft Neo-Brutalism visual system.
/// Flat colors only: no gradients and no glow. Images are used as full-bleed
/// backgrounds/banners; UI surfaces use hard cartoon-like offset shadows.
class XiteraxColors {
  static const background = Color(0xFFF2F0EA);
  static const surface = Color(0xFFFFFFFF);
  static const surfaceSoft = Color(0xFFE6E3DC);
  static const surfaceRaised = Color(0xFFCAC7BF);
  static const black = Color(0xFF111111);
  static const white = Color(0xFFFFFFFF);
  static const grey = Color(0xFF686868);
  static const greyDark = Color(0xFF3D3D3D);
  static const yellow = orange;
  static const orange = Color(0xFFFF8A1F);
  static const green = blue;
  static const blue = Color(0xFF2E86D1);
  static const red = orange;
  static const divider = Color(0xFF171717);
  static const muted = Color(0xFF8A8A84);
  static const navy = Color(0xFF2F80C9);
  static const navySoft = Color(0xFFDCEAF6);
}

class XiteraxNeoCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final BorderRadius borderRadius;
  final Color color;
  final Color borderColor;
  final double borderWidth;
  final Offset shadowOffset;
  final bool shadow;
  final bool texture;

  const XiteraxNeoCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.borderRadius = const BorderRadius.all(Radius.circular(14)),
    this.color = XiteraxColors.white,
    this.borderColor = XiteraxColors.black,
    this.borderWidth = 2.6,
    this.shadowOffset = const Offset(6, 7),
    this.shadow = true,
    this.texture = true,
  });

  @override
  Widget build(BuildContext context) => Container(
        decoration: BoxDecoration(
          color: color,
          borderRadius: borderRadius,
          border: Border.all(color: borderColor, width: borderWidth),
          boxShadow: shadow ? [BoxShadow(color: XiteraxColors.black, offset: shadowOffset, blurRadius: 0)] : null,
        ),
        child: ClipRRect(
          borderRadius: borderRadius.subtract(BorderRadius.all(Radius.circular(borderWidth + 1))),
          child: Stack(
            children: [
              if (texture) const Positioned.fill(child: IgnorePointer(child: CustomPaint(painter: _NeoTexturePainter()))),
              Padding(padding: padding, child: child),
            ],
          ),
        ),
      );
}

class _NeoTexturePainter extends CustomPainter {
  const _NeoTexturePainter();
  @override
  void paint(Canvas canvas, Size size) {
    final line = Paint()..color = const Color(0x17000000)..strokeWidth = 1.15;
    final dot = Paint()..color = const Color(0x12000000);
    for (double x = -size.height; x < size.width + size.height; x += 42) {
      canvas.drawLine(Offset(x, 0), Offset(x + size.height, size.height), line);
    }
    for (double x = 18; x < size.width; x += 38) {
      for (double y = 18; y < size.height; y += 38) {
        canvas.drawCircle(Offset(x, y), 1.5, dot);
      }
    }
  }
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class XiteraxBackground extends StatelessWidget {
  final Widget child;
  final bool darken;
  final String? imageAsset;
  final BoxFit fit;

  const XiteraxBackground({
    super.key,
    required this.child,
    this.darken = false,
    this.imageAsset,
    this.fit = BoxFit.cover,
  });

  @override
  Widget build(BuildContext context) => ColoredBox(
        color: XiteraxColors.background,
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (imageAsset != null)
              Image.asset(imageAsset!, fit: fit, errorBuilder: (_, __, ___) => const SizedBox.shrink()),
            if (darken) const ColoredBox(color: Color(0x33000000)),
            child,
          ],
        ),
      );
}

class XiteraxMenuBackground extends StatelessWidget {
  final Widget child;
  const XiteraxMenuBackground({super.key, required this.child});
  @override
  Widget build(BuildContext context) => XiteraxBackground(child: child, imageAsset: 'assets/images/xiterax_bug_background.jpg');
}

class XiteraxGlass extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final BorderRadius borderRadius;
  final Color? borderColor;
  final Color? color;
  final double borderWidth;
  final bool shadow;
  const XiteraxGlass({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.borderRadius = const BorderRadius.all(Radius.circular(14)),
    this.borderColor,
    this.color,
    this.borderWidth = 2,
    this.shadow = true,
  });
  @override
  Widget build(BuildContext context) => XiteraxNeoCard(
        padding: padding,
        borderRadius: borderRadius,
        borderColor: borderColor ?? XiteraxColors.black,
        borderWidth: borderWidth,
        color: color ?? XiteraxColors.white,
        shadow: shadow,
        child: child,
      );
}

ThemeData xiteraxTheme() {
  final shape = RoundedRectangleBorder(
    borderRadius: BorderRadius.circular(16),
    side: const BorderSide(color: XiteraxColors.black, width: 2),
  );
  return ThemeData(
    useMaterial3: true,
    brightness: Brightness.light,
    fontFamily: 'Baloo2',
    scaffoldBackgroundColor: XiteraxColors.background,
    canvasColor: XiteraxColors.background,
    colorScheme: const ColorScheme.light(
      primary: XiteraxColors.orange,
      onPrimary: XiteraxColors.black,
      secondary: XiteraxColors.blue,
      onSecondary: XiteraxColors.white,
      surface: XiteraxColors.white,
      onSurface: XiteraxColors.black,
      error: XiteraxColors.red,
      onError: XiteraxColors.white,
    ),
    dividerColor: XiteraxColors.black,
    splashFactory: InkRipple.splashFactory,
    textTheme: const TextTheme(
      bodyLarge: TextStyle(color: XiteraxColors.black),
      bodyMedium: TextStyle(color: XiteraxColors.black),
      bodySmall: TextStyle(color: XiteraxColors.greyDark),
      titleLarge: TextStyle(color: XiteraxColors.black, fontWeight: FontWeight.w900),
      titleMedium: TextStyle(color: XiteraxColors.black, fontWeight: FontWeight.w900),
      labelLarge: TextStyle(color: XiteraxColors.black, fontWeight: FontWeight.w900),
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: Colors.transparent,
      surfaceTintColor: Colors.transparent,
      elevation: 0,
      centerTitle: false,
      foregroundColor: XiteraxColors.black,
      titleTextStyle: TextStyle(fontFamily: 'Baloo2', fontSize: 21, fontWeight: FontWeight.w900, color: XiteraxColors.black, letterSpacing: 1.1),
    ),
    cardTheme: CardThemeData(color: XiteraxColors.white, elevation: 0, margin: EdgeInsets.zero, shape: shape),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: XiteraxColors.white,
      contentPadding: const EdgeInsets.symmetric(horizontal: 15, vertical: 14),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: XiteraxColors.black, width: 2)),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: XiteraxColors.black, width: 2)),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: XiteraxColors.blue, width: 3)),
      labelStyle: const TextStyle(color: XiteraxColors.greyDark, fontWeight: FontWeight.w800),
      hintStyle: const TextStyle(color: XiteraxColors.grey),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(style: ElevatedButton.styleFrom(
      backgroundColor: XiteraxColors.orange,
      foregroundColor: XiteraxColors.black,
      elevation: 0,
      minimumSize: const Size.fromHeight(52),
      side: const BorderSide(color: XiteraxColors.black, width: 2),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      textStyle: const TextStyle(fontFamily: 'Baloo2', fontSize: 15, fontWeight: FontWeight.w900),
    )),
    outlinedButtonTheme: OutlinedButtonThemeData(style: OutlinedButton.styleFrom(
      foregroundColor: XiteraxColors.black,
      backgroundColor: XiteraxColors.white,
      side: const BorderSide(color: XiteraxColors.black, width: 2),
      minimumSize: const Size.fromHeight(50),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      textStyle: const TextStyle(fontFamily: 'Baloo2', fontWeight: FontWeight.w900),
    )),
    snackBarTheme: const SnackBarThemeData(backgroundColor: XiteraxColors.black, contentTextStyle: TextStyle(color: XiteraxColors.white)),
    dialogTheme: const DialogThemeData(backgroundColor: XiteraxColors.white, surfaceTintColor: Colors.transparent),
    bottomSheetTheme: const BottomSheetThemeData(backgroundColor: XiteraxColors.white, surfaceTintColor: Colors.transparent),
  );
}
