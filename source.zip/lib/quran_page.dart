import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'xiterax_theme.dart';

class QuranPage extends StatefulWidget {
  const QuranPage({super.key});
  @override
  State<QuranPage> createState() => _QuranPageState();
}

class _QuranPageState extends State<QuranPage> {
  bool _loading = true;
  String? _error;
  List<dynamic> _surahs = [];
  Map<String, dynamic>? _selected;
  final _search = TextEditingController();

  @override
  void initState() { super.initState(); _loadSurahs(); }
  @override
  void dispose() { _search.dispose(); super.dispose(); }

  Future<void> _loadSurahs() async {
    try {
      final r = await http.get(Uri.parse('https://api.alquran.cloud/v1/surah')).timeout(const Duration(seconds: 12));
      final d = jsonDecode(r.body);
      if (r.statusCode == 200 && d['status'] == 'OK') {
        setState(() { _surahs = List<dynamic>.from(d['data'] ?? []); _loading = false; });
      } else { throw Exception('API tidak tersedia'); }
    } catch (e) { if (mounted) setState(() { _loading = false; _error = 'Gagal memuat daftar surah'; }); }
  }

  Future<void> _openSurah(Map<String, dynamic> surah) async {
    showDialog(context: context, barrierDismissible: false, builder: (_) => const Center(child: CircularProgressIndicator(color: XiteraxColors.orange)));
    try {
      final id = surah['number'];
      final r = await http.get(Uri.parse('https://api.alquran.cloud/v1/surah/$id/editions/quran-uthmani,id.indonesian')).timeout(const Duration(seconds: 12));
      final d = jsonDecode(r.body);
      if (mounted) Navigator.pop(context);
      if (r.statusCode == 200 && d['status'] == 'OK' && d['data'] is List) {
        final editions = List<dynamic>.from(d['data']);
        final arabic = Map<String, dynamic>.from(editions.first as Map);
        final indo = Map<String, dynamic>.from(editions.length > 1 ? editions[1] as Map : editions.first as Map);
        final a = List<dynamic>.from(arabic['ayahs'] ?? []);
        final t = List<dynamic>.from(indo['ayahs'] ?? []);
        for (var i = 0; i < a.length; i++) {
          final item = Map<String, dynamic>.from(a[i] as Map);
          item['translation'] = {'text': i < t.length ? '${t[i]['text'] ?? ''}' : ''};
          a[i] = item;
        }
        arabic['ayahs'] = a;
        arabic['englishName'] = surah['englishName'];
        arabic['englishNameTranslation'] = surah['englishNameTranslation'];
        arabic['numberOfAyahs'] = surah['numberOfAyahs'];
        setState(() => _selected = arabic);
      } else { throw Exception(); }
    } catch (_) {
      if (mounted) { Navigator.of(context, rootNavigator: true).maybePop(); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Surah gagal dimuat'))); }
    }
  }

  @override
  Widget build(BuildContext context) {
    final q = _search.text.toLowerCase();
    final filtered = _surahs.where((s) => '${s['number']} ${s['englishName']} ${s['name']}'.toLowerCase().contains(q)).toList();
    return Scaffold(
      backgroundColor: XiteraxColors.background,
      appBar: AppBar(title: const Text('AL-QURAN XITERAX'), actions: [IconButton(onPressed: _loadSurahs, icon: const Icon(Icons.refresh_rounded))]),
      body: _selected != null ? _reader() : ListView(padding: const EdgeInsets.fromLTRB(14, 8, 14, 28), children: [
        XiteraxNeoCard(color: XiteraxColors.orange, child: const Row(children: [Icon(Icons.menu_book_rounded, size: 30), SizedBox(width: 10), Expanded(child: Text('AL-QURAN • BACA & CARI SURAH', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)))])),
        const SizedBox(height: 12),
        TextField(controller: _search, onChanged: (_) => setState(() {}), decoration: const InputDecoration(prefixIcon: Icon(Icons.search_rounded), hintText: 'Cari nama atau nomor surah')),
        const SizedBox(height: 12),
        if (_loading) const Padding(padding: EdgeInsets.all(30), child: Center(child: CircularProgressIndicator(color: XiteraxColors.orange))),
        if (_error != null) XiteraxNeoCard(child: Text(_error!, style: const TextStyle(fontWeight: FontWeight.w900))),
        ...filtered.map((s) => Padding(padding: const EdgeInsets.only(bottom: 8), child: XiteraxNeoCard(padding: const EdgeInsets.all(11), child: InkWell(onTap: () => _openSurah(Map<String, dynamic>.from(s)), child: Row(children: [Container(width: 42, height: 42, alignment: Alignment.center, decoration: BoxDecoration(color: XiteraxColors.black, borderRadius: BorderRadius.circular(12)), child: Text('${s['number']}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900))), const SizedBox(width: 11), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('${s['name']}', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900)), Text('${s['englishName']} • ${s['numberOfAyahs']} ayat', style: const TextStyle(color: XiteraxColors.grey, fontWeight: FontWeight.w700))])), const Icon(Icons.arrow_forward_rounded)]))))),
      ]),
    );
  }

  Widget _reader() {
    final s = _selected!;
    final ayahs = List<dynamic>.from(s['ayahs'] ?? []);
    return ListView(padding: const EdgeInsets.fromLTRB(14, 8, 14, 28), children: [
      Row(children: [IconButton(onPressed: () => setState(() => _selected = null), icon: const Icon(Icons.arrow_back_rounded)), Expanded(child: Text('${s['name']} • ${s['englishName']}', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)))]),
      XiteraxNeoCard(color: XiteraxColors.surfaceSoft, child: Center(child: Column(children: [Text('${s['englishNameTranslation'] ?? ''}', style: const TextStyle(fontWeight: FontWeight.w900)), Text('${s['revelationType'] ?? ''} • ${ayahs.length} ayat', style: const TextStyle(color: XiteraxColors.grey, fontWeight: FontWeight.w700))]))),
      const SizedBox(height: 10),
      ...ayahs.map((a) => Padding(padding: const EdgeInsets.only(bottom: 8), child: XiteraxNeoCard(padding: const EdgeInsets.all(13), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(children: [Container(width: 30, height: 30, alignment: Alignment.center, decoration: BoxDecoration(color: XiteraxColors.orange, borderRadius: BorderRadius.circular(9), border: Border.all(color: XiteraxColors.black, width: 1.5)), child: Text('${a['numberInSurah']}', style: const TextStyle(fontWeight: FontWeight.w900))), const Spacer(), Text('${a['juz'] ?? ''}', style: const TextStyle(color: XiteraxColors.grey, fontWeight: FontWeight.w800))]), const SizedBox(height: 10), Text('${a['text'] ?? ''}', textAlign: TextAlign.right, style: const TextStyle(fontSize: 19, height: 1.8, fontWeight: FontWeight.w700)), const SizedBox(height: 8), Text('${a['translation']?['text'] ?? ''}', style: const TextStyle(fontSize: 12, height: 1.45, color: XiteraxColors.greyDark, fontWeight: FontWeight.w600))])))),
    ]);
  }
}
