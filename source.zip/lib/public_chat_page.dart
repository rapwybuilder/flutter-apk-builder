import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'app_config.dart';
import 'xiterax_theme.dart';

class PublicChatPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;
  final bool embedded;

  const PublicChatPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
    this.embedded = false,
  });

  @override
  State<PublicChatPage> createState() => _PublicChatPageState();
}

class _PublicChatPageState extends State<PublicChatPage> {
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  List<ChatMessage> _messages = [];
  bool _isLoading = true;
  bool _isSending = false;
  int _onlineCount = 0;
  Timer? _pollingTimer;
  Timer? _onlineTimer;
  String? _lastMessageId;
  final String _baseUrl = apiBaseUrl;

  @override
  void initState() {
    super.initState();
    _loadMessages();
    _pollingTimer = Timer.periodic(const Duration(seconds: 3), (_) => _checkNewMessages());
    _onlineTimer = Timer.periodic(const Duration(seconds: 10), (_) => _fetchOnlineUsers());
    _fetchOnlineUsers();
  }

  @override
  void dispose() {
    _pollingTimer?.cancel();
    _onlineTimer?.cancel();
    _messageController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  Future<void> _loadMessages() async {
    if (mounted) setState(() => _isLoading = true);
    try {
      final response = await http.get(Uri.parse('$_baseUrl/getPublicChat?key=${widget.sessionKey}'));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true && mounted) {
          setState(() {
            _messages = (data['messages'] as List).map((e) => ChatMessage.fromJson(e)).toList();
            if (_messages.isNotEmpty) _lastMessageId = _messages.first.id;
          });
        }
      }
    } catch (_) {
      _snack('Gagal memuat chat global', error: true);
    } finally {
      if (mounted) setState(() => _isLoading = false);
      _scrollToBottom();
    }
  }

  Future<void> _checkNewMessages() async {
    if (_lastMessageId == null) return;
    try {
      final response = await http.get(Uri.parse('$_baseUrl/getPublicChat?key=${widget.sessionKey}&lastId=$_lastMessageId'));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true && data['messages'] is List && (data['messages'] as List).isNotEmpty && mounted) {
          final incoming = (data['messages'] as List).map((e) => ChatMessage.fromJson(e)).toList();
          setState(() {
            _messages.insertAll(0, incoming);
            _lastMessageId = _messages.first.id;
          });
        }
      }
    } catch (_) {}
  }

  Future<void> _fetchOnlineUsers() async {
    try {
      final response = await http.get(Uri.parse('$_baseUrl/getOnlineUsers?key=${widget.sessionKey}'));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true && mounted) setState(() => _onlineCount = int.tryParse('${data['count']}') ?? 0);
      }
    } catch (_) {}
  }

  Future<void> _sendMessage() async {
    final text = _messageController.text.trim();
    if (text.isEmpty || _isSending) return;
    setState(() => _isSending = true);
    try {
      final response = await http.post(
        Uri.parse('$_baseUrl/sendPublicChat'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'key': widget.sessionKey, 'message': text}),
      );
      final data = jsonDecode(response.body);
      if (data['valid'] == true) {
        final message = ChatMessage.fromJson(data['message']);
        _messageController.clear();
        if (mounted) {
          setState(() {
            _messages.insert(0, message);
            _lastMessageId = message.id;
          });
        }
        _scrollToBottom();
      } else {
        _snack(data['message'] ?? 'Gagal mengirim pesan', error: true);
      }
    } catch (_) {
      _snack('Gagal mengirim pesan', error: true);
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  Future<void> _deleteMessage(String id, String owner) async {
    final allowed = widget.role.toLowerCase() == 'owner' || owner == widget.username;
    if (!allowed) {
      _snack('Pesan ini bukan milik kamu', error: true);
      return;
    }
    final yes = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: XiteraxColors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18), side: const BorderSide(color: XiteraxColors.black, width: 2)),
        title: const Text('HAPUS PESAN', style: TextStyle(fontWeight: FontWeight.w900)),
        content: const Text('Pesan akan dihapus dari CHAT GLOBAL.', style: TextStyle(fontWeight: FontWeight.w600)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('BATAL')),
          ElevatedButton.icon(onPressed: () => Navigator.pop(context, true), icon: const Icon(Icons.delete_outline_rounded), label: const Text('HAPUS')),
        ],
      ),
    );
    if (yes != true) return;
    try {
      final response = await http.delete(
        Uri.parse('$_baseUrl/deletePublicChat'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'key': widget.sessionKey, 'messageId': id}),
      );
      final data = jsonDecode(response.body);
      if (data['valid'] == true && mounted) {
        setState(() => _messages.removeWhere((m) => m.id == id));
        _snack('Pesan dihapus');
      } else {
        _snack(data['message'] ?? 'Gagal menghapus pesan', error: true);
      }
    } catch (_) {
      _snack('Gagal menghapus pesan', error: true);
    }
  }

  void _snack(String text, {bool error = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Row(children: [Icon(error ? Icons.close_rounded : Icons.check_rounded, color: XiteraxColors.white), const SizedBox(width: 8), Expanded(child: Text(text, style: const TextStyle(fontWeight: FontWeight.w800)))]),
      backgroundColor: error ? XiteraxColors.black : XiteraxColors.blue,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: const BorderSide(color: XiteraxColors.black, width: 2)),
    ));
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) _scrollController.animateTo(0, duration: const Duration(milliseconds: 260), curve: Curves.easeOut);
    });
  }

  Color _roleColor(String role) {
    switch (role.toLowerCase()) {
      case 'owner': return XiteraxColors.orange;
      case 'admin': return XiteraxColors.blue;
      case 'vip': return XiteraxColors.blue;
      default: return XiteraxColors.greyDark;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: XiteraxColors.background,
      appBar: AppBar(
        toolbarHeight: 70,
        automaticallyImplyLeading: !widget.embedded,
        leading: widget.embedded ? null : IconButton(onPressed: () => Navigator.maybePop(context), icon: const Icon(Icons.arrow_back_rounded, size: 27)),
        titleSpacing: 0,
        title: Row(children: [
          Container(width: 42, height: 42, decoration: BoxDecoration(color: XiteraxColors.blue, border: Border.all(color: XiteraxColors.black, width: 2), borderRadius: BorderRadius.circular(12), boxShadow: const [BoxShadow(color: XiteraxColors.black, offset: Offset(3, 4), blurRadius: 0)]), child: const Icon(Icons.forum_rounded, color: XiteraxColors.white)),
          const SizedBox(width: 10),
          const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('CHAT GLOBAL', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, letterSpacing: 1)), Text('RUANG KOMUNITAS XITERAX', style: TextStyle(fontSize: 8, fontWeight: FontWeight.w900, color: XiteraxColors.greyDark))]),
        ]),
        actions: [
          Container(margin: const EdgeInsets.only(right: 12), padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7), decoration: BoxDecoration(color: XiteraxColors.white, border: Border.all(color: XiteraxColors.black, width: 2), borderRadius: BorderRadius.circular(11), boxShadow: const [BoxShadow(color: XiteraxColors.black, offset: Offset(3, 3), blurRadius: 0)]), child: Row(children: [Container(width: 8, height: 8, decoration: const BoxDecoration(color: XiteraxColors.blue, shape: BoxShape.circle)), const SizedBox(width: 6), Text('$_onlineCount ONLINE', style: const TextStyle(fontSize: 9, fontWeight: FontWeight.w900))])),
        ],
      ),
      body: SafeArea(
        top: false,
        child: Column(children: [
          Padding(padding: const EdgeInsets.fromLTRB(14, 2, 14, 10), child: _chatHeader()),
          Expanded(child: _isLoading ? const Center(child: CircularProgressIndicator(color: XiteraxColors.blue, strokeWidth: 3)) : _messages.isEmpty ? _empty() : ListView.builder(controller: _scrollController, reverse: true, padding: const EdgeInsets.fromLTRB(14, 4, 14, 14), itemCount: _messages.length, itemBuilder: (_, i) { final msg = _messages[i]; final mine = msg.username == widget.username; return GestureDetector(onLongPress: () => _deleteMessage(msg.id, msg.username), child: _message(msg, mine)); })),
          _composer(),
        ]),
      ),
    );
  }

  Widget _chatHeader() => XiteraxNeoCard(
    padding: const EdgeInsets.all(12),
    color: XiteraxColors.black,
    borderRadius: BorderRadius.circular(16),
    child: Row(children: [
      Container(width: 38, height: 38, decoration: BoxDecoration(color: XiteraxColors.orange, border: Border.all(color: XiteraxColors.white, width: 2), shape: BoxShape.circle), child: const Icon(Icons.public_rounded, color: XiteraxColors.black)),
      const SizedBox(width: 10),
      const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('GLOBAL LOUNGE', style: TextStyle(color: XiteraxColors.white, fontSize: 13, fontWeight: FontWeight.w900, letterSpacing: 1)), SizedBox(height: 2), Text('Bagikan info • ngobrol • saling bantu', style: TextStyle(color: XiteraxColors.surfaceSoft, fontSize: 9, fontWeight: FontWeight.w700))])),
      Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6), decoration: BoxDecoration(color: XiteraxColors.white, border: Border.all(color: XiteraxColors.white, width: 1), borderRadius: BorderRadius.circular(8)), child: const Text('LIVE', style: TextStyle(fontSize: 8, fontWeight: FontWeight.w900))),
    ]),
  );

  Widget _empty() => Center(child: Padding(padding: const EdgeInsets.all(30), child: XiteraxNeoCard(padding: const EdgeInsets.all(22), child: Column(mainAxisSize: MainAxisSize.min, children: [Container(width: 64, height: 64, decoration: BoxDecoration(color: XiteraxColors.blue, border: Border.all(color: XiteraxColors.black, width: 2), shape: BoxShape.circle), child: const Icon(Icons.forum_outlined, color: XiteraxColors.white, size: 31)), const SizedBox(height: 13), const Text('BELUM ADA OBROLAN', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 15)), const SizedBox(height: 4), const Text('Mulai percakapan pertama di ruang global.', textAlign: TextAlign.center, style: TextStyle(color: XiteraxColors.greyDark, fontSize: 11, fontWeight: FontWeight.w700))]))));

  Widget _message(ChatMessage msg, bool mine) {
    final roleColor = _roleColor(msg.role);
    return Padding(padding: const EdgeInsets.only(bottom: 10), child: Row(mainAxisAlignment: mine ? MainAxisAlignment.end : MainAxisAlignment.start, crossAxisAlignment: CrossAxisAlignment.end, children: [
      if (!mine) ...[
        Container(width: 36, height: 36, margin: const EdgeInsets.only(right: 7), decoration: BoxDecoration(color: XiteraxColors.white, border: Border.all(color: XiteraxColors.black, width: 2), borderRadius: BorderRadius.circular(10), boxShadow: const [BoxShadow(color: XiteraxColors.black, offset: Offset(2, 3), blurRadius: 0)]), child: Center(child: Text(msg.username.isEmpty ? '?' : msg.username[0].toUpperCase(), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15)))),
      ],
      Flexible(child: Container(constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * .78), padding: const EdgeInsets.fromLTRB(12, 9, 12, 8), decoration: BoxDecoration(color: mine ? XiteraxColors.blue : XiteraxColors.white, border: Border.all(color: XiteraxColors.black, width: 2), borderRadius: BorderRadius.only(topLeft: const Radius.circular(15), topRight: const Radius.circular(15), bottomLeft: Radius.circular(mine ? 15 : 4), bottomRight: Radius.circular(mine ? 4 : 15)), boxShadow: const [BoxShadow(color: XiteraxColors.black, offset: Offset(3, 4), blurRadius: 0)]), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        if (!mine) Row(children: [Flexible(child: Text(msg.username, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: roleColor, fontSize: 11, fontWeight: FontWeight.w900))), const SizedBox(width: 5), _roleTag(msg.role, roleColor)]),
        if (!mine) const SizedBox(height: 4),
        Text(msg.message, style: TextStyle(color: mine ? XiteraxColors.white : XiteraxColors.black, fontSize: 13, fontWeight: FontWeight.w700, height: 1.2)),
        const SizedBox(height: 5),
        Align(alignment: Alignment.centerRight, child: Text(msg.formattedTime, style: TextStyle(color: mine ? XiteraxColors.white : XiteraxColors.grey, fontSize: 8, fontWeight: FontWeight.w800))),
      ]))),
    ]));
  }

  Widget _roleTag(String role, Color color) => Container(padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2), decoration: BoxDecoration(color: color, border: Border.all(color: XiteraxColors.black, width: 1), borderRadius: BorderRadius.circular(5)), child: Text(role.toUpperCase(), style: TextStyle(color: color == XiteraxColors.orange ? XiteraxColors.black : XiteraxColors.white, fontSize: 6, fontWeight: FontWeight.w900)));

  Widget _composer() => Container(padding: const EdgeInsets.fromLTRB(12, 9, 12, 11), decoration: const BoxDecoration(color: XiteraxColors.white, border: Border(top: BorderSide(color: XiteraxColors.black, width: 2))), child: Row(children: [
    Expanded(child: Container(decoration: BoxDecoration(color: XiteraxColors.surfaceSoft, border: Border.all(color: XiteraxColors.black, width: 2), borderRadius: BorderRadius.circular(14)), child: TextField(controller: _messageController, minLines: 1, maxLines: 4, textInputAction: TextInputAction.newline, style: const TextStyle(color: XiteraxColors.black, fontWeight: FontWeight.w700, fontSize: 13), decoration: const InputDecoration(hintText: 'Tulis pesan ke global...', hintStyle: TextStyle(color: XiteraxColors.grey, fontWeight: FontWeight.w700, fontSize: 12), border: InputBorder.none, contentPadding: EdgeInsets.symmetric(horizontal: 13, vertical: 11)), onSubmitted: (_) => _sendMessage()))),
    const SizedBox(width: 8),
    GestureDetector(onTap: _isSending ? null : _sendMessage, child: AnimatedContainer(duration: const Duration(milliseconds: 180), width: 48, height: 48, decoration: BoxDecoration(color: _isSending ? XiteraxColors.grey : XiteraxColors.orange, border: Border.all(color: XiteraxColors.black, width: 2), borderRadius: BorderRadius.circular(13), boxShadow: const [BoxShadow(color: XiteraxColors.black, offset: Offset(3, 4), blurRadius: 0)]), child: _isSending ? const Padding(padding: EdgeInsets.all(13), child: CircularProgressIndicator(strokeWidth: 2, color: XiteraxColors.white)) : const Icon(Icons.arrow_upward_rounded, color: XiteraxColors.black, size: 25))),
  ]));
}

class ChatMessage {
  final String id;
  final String username;
  final String role;
  final String message;
  final String timestamp;
  final String formattedTime;

  ChatMessage({required this.id, required this.username, required this.role, required this.message, required this.timestamp, required this.formattedTime});

  factory ChatMessage.fromJson(Map<String, dynamic> json) => ChatMessage(
    id: '${json['id'] ?? ''}',
    username: '${json['username'] ?? ''}',
    role: '${json['role'] ?? 'member'}',
    message: '${json['message'] ?? ''}',
    timestamp: '${json['timestamp'] ?? DateTime.now().toIso8601String()}',
    formattedTime: '${json['formattedTime'] ?? ''}',
  );
}
