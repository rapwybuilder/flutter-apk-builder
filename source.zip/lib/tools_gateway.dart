import 'package:flutter/material.dart';
import 'xiterax_theme.dart';
import 'spongebob_ai_page.dart';
import 'spotify_page.dart';
import 'quran_page.dart';
import 'games_page.dart';
import 'calculator_page.dart';
import 'weather_page.dart';
import 'jadwal_sholat_page.dart';
import 'qr_gen.dart';
import 'anime.dart';
import 'tiktok_page.dart';
import 'instagram_page.dart';
import 'shortlink_page.dart';
import 'phone_lookup_page.dart';
import 'domain_page.dart';

class ToolsPage extends StatefulWidget {
  final String sessionKey;
  final String userRole;
  final List<Map<String, dynamic>> listDoos;
  final VoidCallback? onMenu;
  final VoidCallback? onProfile;
  const ToolsPage({super.key, required this.sessionKey, required this.userRole, required this.listDoos, this.onMenu, this.onProfile});
  @override State<ToolsPage> createState() => _ToolsPageState();
}

class _ToolsPageState extends State<ToolsPage> {
  String _filter = 'ALL';
  late final List<_ToolItem> _tools = [
    const _ToolItem(Icons.smart_toy_rounded, 'AI', 'XITERAX AI ASSISTANT', 'SMART', XiteraxColors.orange),
    const _ToolItem(Icons.music_note_rounded, 'SPOTIFY', 'SPOTIFY PLAY', 'MEDIA', XiteraxColors.blue),
    const _ToolItem(Icons.menu_book_rounded, 'QURAN', 'AL-QURAN', 'DAILY', XiteraxColors.surfaceSoft),
    const _ToolItem(Icons.sports_esports_rounded, 'GAMES', 'MINI GAMES', 'FUN', XiteraxColors.orange),
    const _ToolItem(Icons.calculate_rounded, 'CALC', 'CALCULATOR', 'UTILITY', XiteraxColors.surfaceSoft),
    const _ToolItem(Icons.cloud_rounded, 'WEATHER', 'WEATHER CHECK', 'DAILY', XiteraxColors.blue),
    const _ToolItem(Icons.access_time_filled_rounded, 'SHOLAT', 'JADWAL SHOLAT', 'DAILY', XiteraxColors.surfaceSoft),
    const _ToolItem(Icons.qr_code_rounded, 'QR', 'QR GENERATOR', 'UTILITY', XiteraxColors.orange),
    const _ToolItem(Icons.movie_filter_rounded, 'ANIME', 'ANIME CENTER', 'MEDIA', XiteraxColors.blue),
    const _ToolItem(Icons.music_video_rounded, 'TIKTOK', 'TIKTOK TOOL', 'MEDIA', XiteraxColors.surfaceSoft),
    const _ToolItem(Icons.camera_alt_rounded, 'INSTAGRAM', 'INSTAGRAM TOOL', 'MEDIA', XiteraxColors.orange),
    const _ToolItem(Icons.link_rounded, 'SHORTLINK', 'SHORT LINK', 'UTILITY', XiteraxColors.blue),
    const _ToolItem(Icons.phone_rounded, 'PHONE', 'PHONE LOOKUP', 'UTILITY', XiteraxColors.surfaceSoft),
    const _ToolItem(Icons.language_rounded, 'DOMAIN', 'DOMAIN CHECK', 'UTILITY', XiteraxColors.orange),
  ];

  List<_ToolItem> get _visible => _filter == 'ALL' ? _tools : _tools.where((t) => t.category == _filter).toList();

  void _openTool(_ToolItem t) {
    Widget page;
    switch (t.label) {
      case 'AI': page = const XiteraxAiPage(); break;
      case 'SPOTIFY': page = const SpotifyPage(); break;
      case 'QURAN': page = const QuranPage(); break;
      case 'GAMES': page = const GamesPage(); break;
      case 'CALC': page = const CalculatorPage(); break;
      case 'WEATHER': page = WeatherPage(sessionKey: widget.sessionKey, username: 'xiterax'); break;
      case 'SHOLAT': page = JadwalSholatPage(sessionKey: widget.sessionKey, username: 'xiterax'); break;
      case 'QR': page = const QrGeneratorPage(); break;
      case 'ANIME': page = HomeAnimePage(username: 'xiterax', role: widget.userRole); break;
      case 'TIKTOK': page = const TiktokDownloaderPage(); break;
      case 'INSTAGRAM': page = const InstagramDownloaderPage(); break;
      case 'SHORTLINK': page = ShortlinkPage(sessionKey: widget.sessionKey); break;
      case 'PHONE': page = PhoneLookupPage(sessionKey: widget.sessionKey); break;
      case 'DOMAIN': page = const DomainOsintPage(); break;
      default: return;
    }
    Navigator.push(context, MaterialPageRoute(builder: (_) => page));
  }

  @override
  Widget build(BuildContext context) {
    final visible = _visible;
    return XiteraxBackground(
      imageAsset: 'assets/images/xiterax_menu_background.jpg',
      child: ListView(padding: const EdgeInsets.fromLTRB(14, 12, 14, 30), children: [
        XiteraxNeoCard(padding: const EdgeInsets.fromLTRB(10, 9, 10, 12), child: Row(children: [
          Container(width: 42, height: 42, decoration: BoxDecoration(color: XiteraxColors.black, borderRadius: BorderRadius.circular(12), border: Border.all(color: XiteraxColors.black, width: 2)), child: const Icon(Icons.handyman_rounded, color: Colors.white)),
          const SizedBox(width: 9), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('TOOLS XITERAX', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900, letterSpacing: 1)), Text('${_tools.length} TOOLS • ${_visible.length} DITAMPILKAN', style: const TextStyle(fontSize: 9, fontWeight: FontWeight.w900, color: XiteraxColors.grey))])),
          if (widget.onMenu != null) _action(Icons.menu_rounded, widget.onMenu!), if (widget.onProfile != null) ...[const SizedBox(width: 6), _action(Icons.person_rounded, widget.onProfile!)],
        ])),
        const SizedBox(height: 12),
        XiteraxNeoCard(color: XiteraxColors.black, child: const Row(children: [Icon(Icons.bolt_rounded, color: XiteraxColors.orange, size: 26), SizedBox(width: 9), Expanded(child: Text('TOOLBOX AKTIF\nPilih tool yang mau dipakai. Semua kartu memakai sistem UI XITERAX.', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 11, height: 1.4)))])),
        const SizedBox(height: 12),
        SingleChildScrollView(scrollDirection: Axis.horizontal, child: Row(children: ['ALL','SMART','MEDIA','DAILY','UTILITY','FUN'].map((f) => Padding(padding: const EdgeInsets.only(right: 7), child: _filterChip(f))).toList())),
        const SizedBox(height: 13),
        GridView.builder(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), itemCount: visible.length, gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: .94), itemBuilder: (_, i) => _toolCard(visible[i], i, visible.length)),
        const SizedBox(height: 14),
        XiteraxNeoCard(color: XiteraxColors.surfaceSoft, child: const Row(children: [Icon(Icons.check_circle_rounded), SizedBox(width: 9), Expanded(child: Text('TOOLBOX XITERAX • pilih utility, media, daily tools, atau games yang ingin dipakai.', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 11)))])),
      ]),
    );
  }

  Widget _filterChip(String f) => GestureDetector(onTap: () => setState(() => _filter = f), child: Container(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9), decoration: BoxDecoration(color: _filter == f ? XiteraxColors.black : XiteraxColors.white, border: Border.all(color: XiteraxColors.black, width: 2), borderRadius: BorderRadius.circular(12), boxShadow: const [BoxShadow(color: XiteraxColors.black, offset: Offset(3, 3), blurRadius: 0)]), child: Text(f, style: TextStyle(color: _filter == f ? Colors.white : XiteraxColors.black, fontSize: 10, fontWeight: FontWeight.w900))));

  Widget _toolCard(_ToolItem t, int i, int total) => GestureDetector(onTap: () => _openTool(t), child: XiteraxNeoCard(padding: const EdgeInsets.all(11), color: XiteraxColors.white, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Row(children: [Container(width: 43, height: 43, decoration: BoxDecoration(color: t.color, border: Border.all(color: XiteraxColors.black, width: 2), borderRadius: BorderRadius.circular(12)), child: Icon(t.icon, size: 22)), const Spacer(), Container(padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 4), decoration: BoxDecoration(color: XiteraxColors.surfaceSoft, border: Border.all(color: XiteraxColors.black, width: 1.5), borderRadius: BorderRadius.circular(8)), child: Text(t.category, style: const TextStyle(fontSize: 7, fontWeight: FontWeight.w900)))]),
    const Spacer(), Text(t.label, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w900, color: XiteraxColors.grey)), const SizedBox(height: 2), Text(t.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 16, height: 1.05, fontWeight: FontWeight.w900)), const SizedBox(height: 9), Container(width: double.infinity, padding: const EdgeInsets.symmetric(vertical: 7), decoration: BoxDecoration(color: XiteraxColors.black, borderRadius: BorderRadius.circular(9)), child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(Icons.arrow_forward_rounded, color: Colors.white, size: 15), SizedBox(width: 5), Text('BUKA', style: TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w900))])),
  ])));

  Widget _action(IconData icon, VoidCallback onTap) => GestureDetector(onTap: onTap, child: Container(width: 40, height: 40, decoration: BoxDecoration(color: XiteraxColors.surfaceSoft, border: Border.all(color: XiteraxColors.black, width: 2), borderRadius: BorderRadius.circular(11)), child: Icon(icon, size: 19)));
}

class _ToolItem {
  final IconData icon; final String label; final String title; final String category; final Color color;
  const _ToolItem(this.icon, this.label, this.title, this.category, this.color);
}
