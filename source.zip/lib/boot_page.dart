import 'dart:async';
import 'package:flutter/material.dart';
import 'landing.dart';
import 'xiterax_theme.dart';

class XiteraxBootPage extends StatefulWidget {
  const XiteraxBootPage({super.key});
  @override
  State<XiteraxBootPage> createState() => _XiteraxBootPageState();
}

class _XiteraxBootPageState extends State<XiteraxBootPage> with TickerProviderStateMixin {
  late final AnimationController _spin;
  late final AnimationController _entry;
  Timer? _timer;
  int _step = 0;
  final _steps = const [
    ('START', 'Menyiapkan XITERAX'),
    ('CHECK', 'Memeriksa koneksi'),
    ('READY', 'Membuka interface'),
  ];

  @override
  void initState() {
    super.initState();
    _spin = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200))..repeat();
    _entry = AnimationController(vsync: this, duration: const Duration(milliseconds: 600))..forward();
    _timer = Timer.periodic(const Duration(milliseconds: 700), (_) {
      if (!mounted) return;
      setState(() => _step++);
      if (_step >= _steps.length) {
        _timer?.cancel();
        Future.delayed(const Duration(milliseconds: 300), () {
          if (!mounted) return;
          Navigator.of(context).pushReplacement(
            PageRouteBuilder(
              pageBuilder: (_, __, ___) => const LandingPage(),
              transitionsBuilder: (_, a, __, child) => FadeTransition(opacity: a, child: child),
              transitionDuration: const Duration(milliseconds: 450),
            ),
          );
        });
      }
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _spin.dispose();
    _entry.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final active = _step.clamp(0, _steps.length - 1).toInt();
    return Scaffold(
      backgroundColor: XiteraxColors.background,
      body: XiteraxBackground(
        imageAsset: 'assets/images/xiterax_background.jpg',
        child: SafeArea(
          child: FadeTransition(
            opacity: _entry,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 18, 20, 20),
              child: Column(
                children: [
                  _header(),
                  const Spacer(),
                  _logo(),
                  const SizedBox(height: 22),
                  const Text('XITERAX', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900, letterSpacing: 4)),
                  const SizedBox(height: 5),
                  const Text('INTERFACE INITIALIZATION', style: TextStyle(fontSize: 9, fontWeight: FontWeight.w900, color: XiteraxColors.greyDark, letterSpacing: 1.5)),
                  const SizedBox(height: 24),
                  _stepsCard(active),
                  const SizedBox(height: 12),
                  Text(_steps[active].$2, style: const TextStyle(fontSize: 11, color: XiteraxColors.greyDark, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 10),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: LinearProgressIndicator(
                      minHeight: 7,
                      value: ((_step + .35) / _steps.length).clamp(0.0, 1.0),
                      backgroundColor: XiteraxColors.surfaceSoft,
                      valueColor: const AlwaysStoppedAnimation<Color>(XiteraxColors.blue),
                    ),
                  ),
                  const Spacer(),
                  const Text('DESIGN BY RAPWY • XITERAX', style: TextStyle(fontSize: 8, fontWeight: FontWeight.w900, color: XiteraxColors.greyDark, letterSpacing: 1.2)),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _header() => Row(
        children: [
          Container(width: 38, height: 38, decoration: BoxDecoration(color: XiteraxColors.black, border: Border.all(color: XiteraxColors.black, width: 2), borderRadius: BorderRadius.circular(11)), child: const Icon(Icons.bolt_rounded, color: XiteraxColors.white)),
          const SizedBox(width: 9),
          const Expanded(child: Text('XITERAX', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, letterSpacing: 2))),
          Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6), decoration: BoxDecoration(color: XiteraxColors.orange, border: Border.all(color: XiteraxColors.black, width: 2), borderRadius: BorderRadius.circular(9)), child: const Text('BOOT', style: TextStyle(fontSize: 8, fontWeight: FontWeight.w900))),
        ],
      );

  Widget _logo() => AnimatedBuilder(
        animation: _spin,
        builder: (_, __) => Transform.rotate(
          angle: _spin.value * 6.283,
          child: Container(
            width: 108,
            height: 108,
            decoration: BoxDecoration(color: XiteraxColors.white, shape: BoxShape.circle, border: Border.all(color: XiteraxColors.black, width: 3), boxShadow: const [BoxShadow(color: XiteraxColors.black, offset: Offset(5, 6), blurRadius: 0)]),
            child: Center(child: Container(width: 74, height: 74, decoration: BoxDecoration(color: XiteraxColors.blue, shape: BoxShape.circle, border: Border.all(color: XiteraxColors.black, width: 3)), child: const Icon(Icons.bolt_rounded, color: XiteraxColors.white, size: 38))),
          ),
        ),
      );

  Widget _stepsCard(int active) => XiteraxNeoCard(
        child: Column(
          children: [
            for (int i = 0; i < _steps.length; i++)
              Padding(
                padding: EdgeInsets.only(bottom: i == _steps.length - 1 ? 0 : 12),
                child: Row(
                  children: [
                    Icon(i < _step ? Icons.check_circle_rounded : i == active ? Icons.radio_button_checked_rounded : Icons.radio_button_unchecked_rounded, size: 18, color: i <= active ? XiteraxColors.orange : XiteraxColors.grey),
                    const SizedBox(width: 10),
                    Expanded(child: Text(_steps[i].$1, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 1))),
                    Text(i < _step ? 'OK' : i == active ? '...' : 'WAIT', style: const TextStyle(fontSize: 9, fontWeight: FontWeight.w900, color: XiteraxColors.greyDark)),
                  ],
                ),
              ),
          ],
        ),
      );
}
