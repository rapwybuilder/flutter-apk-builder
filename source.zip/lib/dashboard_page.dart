import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import 'app_config.dart';
import 'home_page.dart';
import 'tools_gateway.dart';
import 'bug_sender.dart';
import 'profile_page.dart';
import 'public_chat_page.dart';
import 'riwayat_page.dart';
import 'spotify_page.dart';
import 'quran_page.dart';
import 'games_page.dart';
import 'calculator_page.dart';
import 'xiterax_theme.dart';

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
    required this.listDoos,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> with TickerProviderStateMixin {
  late AnimationController _intro;
  late WebSocketChannel _channel;
  late PageController _quickController;
  late PageController _whatsappController;
  Timer? _onlineTimer;
  Timer? _statsTimer;
  Timer? _clockTimer;
  int _page = 0;
  int _quickIndex = 0;
  int _whatsappIndex = 0;
  int onlineUsers = 0;
  int senderCount = 0;
  int deviceCount = 0;
  String _clock = '';

  @override
  void initState() {
    super.initState();
    _intro = AnimationController(vsync: this, duration: const Duration(milliseconds: 650))..forward();
    _quickController = PageController(viewportFraction: .78);
    _whatsappController = PageController(viewportFraction: .76);
    _fetchOnlineUsers();
    _fetchSenderCount();
    _connectStats();
    _updateClock();
    _clockTimer = Timer.periodic(const Duration(seconds: 1), (_) => _updateClock());
    _onlineTimer = Timer.periodic(const Duration(seconds: 10), (_) => _fetchOnlineUsers());
  }

  void _updateClock() {
    if (!mounted) return;
    final n = DateTime.now();
    setState(() => _clock = '${n.hour.toString().padLeft(2, '0')}:${n.minute.toString().padLeft(2, '0')}');
  }

  Future<void> _fetchOnlineUsers() async {
    try {
      final r = await http.get(Uri.parse('$apiBaseUrl/getOnlineUsers?key=${widget.sessionKey}'));
      if (r.statusCode == 200) {
        final d = jsonDecode(r.body);
        if (d['valid'] == true && mounted) setState(() => onlineUsers = int.tryParse('${d['count']}') ?? 0);
      }
    } catch (_) {}
  }

  Future<void> _fetchSenderCount() async {
    try {
      final r = await http.get(Uri.parse('$apiBaseUrl/mySender?key=${widget.sessionKey}'));
      if (r.statusCode == 200) {
        final d = jsonDecode(r.body);
        if (d['valid'] == true && mounted) {
          final privateCount = int.tryParse('${d['privateCount']}') ?? (d['connections'] is List ? (d['connections'] as List).length : 0);
          final globalCount = int.tryParse('${d['globalCount']}') ?? (d['globalConnections'] is List ? (d['globalConnections'] as List).length : 0);
          setState(() {
            senderCount = privateCount + globalCount;
            deviceCount = senderCount;
          });
        }
      }
    } catch (_) {}
  }


  void _connectStats() {
    try {
      _channel = WebSocketChannel.connect(Uri.parse(apiBaseUrl.replaceFirst(RegExp(r'^http'), 'ws')));
      _channel.sink.add(jsonEncode({'type': 'validate', 'key': widget.sessionKey}));
      _channel.sink.add(jsonEncode({'type': 'stats'}));
      _statsTimer = Timer.periodic(const Duration(seconds: 5), (_) => _channel.sink.add(jsonEncode({'type': 'stats'})));
      _channel.stream.listen((event) {
        final d = jsonDecode(event);
        if (d['type'] == 'stats' && mounted) {
          setState(() {
            onlineUsers = int.tryParse('${d['onlineUsers']}') ?? onlineUsers;
            deviceCount = senderCount > 0 ? senderCount : (int.tryParse('${d['activeConnections']}') ?? 0);
          });
        }
      }, onError: (_) {});
    } catch (_) {}
  }

  void _go(int index) => setState(() => _page = index);

  void _openBug(int mode) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => HomePage(
      username: widget.username,
      password: widget.password,
      listBug: widget.listBug,
      role: widget.role,
      expiredDate: widget.expiredDate,
      sessionKey: widget.sessionKey,
      initialMode: mode,
    )));
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      _dashboard(),
      _whatsappChooser(),
      PublicChatPage(sessionKey: widget.sessionKey, username: widget.username, role: widget.role, embedded: true),
      ToolsPage(sessionKey: widget.sessionKey, userRole: widget.role, listDoos: widget.listDoos, onMenu: _showMenu, onProfile: _openProfile),
    ];
    return Scaffold(
      backgroundColor: XiteraxColors.background,
      body: SafeArea(
        child: FadeTransition(opacity: CurvedAnimation(parent: _intro, curve: Curves.easeOut), child: pages[_page]),
      ),
      bottomNavigationBar: _bottomBar(),
    );
  }

  Widget _topTitle(String title, {String? subtitle}) => XiteraxNeoCard(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
    child: Row(children: [
      Container(width: 40, height: 40, decoration: BoxDecoration(color: XiteraxColors.black, border: Border.all(color: XiteraxColors.black, width: 2), borderRadius: BorderRadius.circular(11)), child: Icon(title == 'WHATSAPP' ? FontAwesomeIcons.whatsapp : Icons.dashboard_rounded, color: XiteraxColors.white, size: 18)),
      const SizedBox(width: 10),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900, letterSpacing: 1.1)), if (subtitle != null) Text(subtitle, style: const TextStyle(fontSize: 8, fontWeight: FontWeight.w900, color: XiteraxColors.greyDark, letterSpacing: .7))])),
      _topAction(Icons.menu_rounded, _showMenu),
      const SizedBox(width: 6),
      _topAction(Icons.person_rounded, _openProfile),
    ]),
  );

  Widget _topAction(IconData icon, VoidCallback onTap) => GestureDetector(
    onTap: onTap,
    child: Container(width: 40, height: 40, decoration: BoxDecoration(color: XiteraxColors.surfaceSoft, border: Border.all(color: XiteraxColors.black, width: 2), borderRadius: BorderRadius.circular(11)), child: Icon(icon, size: 19)),
  );

  void _openProfile() {
    Navigator.push(context, MaterialPageRoute(builder: (_) => ProfilePage(username: widget.username, password: widget.password, role: widget.role, expiredDate: widget.expiredDate, sessionKey: widget.sessionKey)));
  }

  void _openGlobalChat() {
    Navigator.push(context, MaterialPageRoute(builder: (_) => PublicChatPage(
      sessionKey: widget.sessionKey,
      username: widget.username,
      role: widget.role,
    )));
  }

  Future<void> _logout() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: XiteraxColors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
          side: const BorderSide(color: XiteraxColors.black, width: 2),
        ),
        title: const Text('LOGOUT?', style: TextStyle(fontWeight: FontWeight.w900)),
        content: const Text('Hapus sesi login dari perangkat ini?', style: TextStyle(fontWeight: FontWeight.w600)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('BATAL')),
          ElevatedButton.icon(onPressed: () => Navigator.pop(dialogContext, true), icon: const Icon(Icons.logout_rounded), label: const Text('LOGOUT')),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('username');
    await prefs.remove('password');
    await prefs.remove('key');
    if (!mounted) return;
    Navigator.of(context).pushNamedAndRemoveUntil('/login', (route) => false);
  }

  void _showMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => Padding(
        padding: const EdgeInsets.all(12),
        child: XiteraxNeoCard(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Row(children: [Container(width: 38, height: 38, decoration: BoxDecoration(color: XiteraxColors.orange, border: Border.all(color: XiteraxColors.black, width: 2), borderRadius: BorderRadius.circular(10)), child: const Icon(Icons.menu_rounded)), const SizedBox(width: 9), const Text('XITERAX MENU', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900))]),
            const SizedBox(height: 10),
            _menuItem(Icons.person_rounded, 'PROFILE', _openProfile),
            _menuItem(Icons.forum_rounded, 'CHAT GLOBAL', _openGlobalChat),
            _menuItem(Icons.handyman_rounded, 'SENDER', () => Navigator.push(context, MaterialPageRoute(builder: (_) => BugSenderPage(sessionKey: widget.sessionKey, username: widget.username, role: widget.role)))),
            _menuItem(Icons.history_rounded, 'RIWAYAT', () => Navigator.push(context, MaterialPageRoute(builder: (_) => RiwayatPage(sessionKey: widget.sessionKey, role: widget.role)))),
            _menuItem(Icons.handyman_rounded, 'TOOLS', () => _go(3)),
            _menuItem(Icons.logout_rounded, 'LOGOUT', _logout),
          ]),
        ),
      ),
    );
  }

  Widget _menuItem(IconData icon, String title, VoidCallback onTap) => Padding(
    padding: const EdgeInsets.only(top: 8),
    child: SizedBox(width: double.infinity, child: OutlinedButton.icon(onPressed: () { Navigator.pop(context); onTap(); }, icon: Icon(icon), label: Align(alignment: Alignment.centerLeft, child: Text(title)))),
  );

  Widget _dashboard() {
    final quick = [
      ('BUG', Icons.bug_report_rounded, XiteraxColors.orange, () => _go(1)),
      ('CHAT GLOBAL', Icons.forum_rounded, XiteraxColors.blue, _openGlobalChat),
      ('SENDER', Icons.handyman_rounded, XiteraxColors.blue, () => Navigator.push(context, MaterialPageRoute(builder: (_) => BugSenderPage(sessionKey: widget.sessionKey, username: widget.username, role: widget.role)))),
      ('RIWAYAT', Icons.history_rounded, XiteraxColors.surfaceSoft, () => Navigator.push(context, MaterialPageRoute(builder: (_) => RiwayatPage(sessionKey: widget.sessionKey, role: widget.role)))),
      ('SPOTIFY', Icons.music_note_rounded, XiteraxColors.orange, () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SpotifyPage()))),
      ('QURAN', Icons.menu_book_rounded, XiteraxColors.surfaceSoft, () => Navigator.push(context, MaterialPageRoute(builder: (_) => const QuranPage()))),
    ];

    return XiteraxBackground(
      imageAsset: 'assets/images/xiterax_dashboard_background.jpg',
      child: ListView(
        padding: const EdgeInsets.fromLTRB(14, 12, 14, 28),
        children: [
          _topTitle('DASHBOARD', subtitle: _clock),
          const SizedBox(height: 14),
          _heroCard(),
          const SizedBox(height: 16),
          _sectionTitle('QUICK ACCESS', Icons.handyman_rounded),
          const SizedBox(height: 9),
          _lockedSlider(quick),
          const SizedBox(height: 16),
          XiteraxNeoCard(color: XiteraxColors.surfaceSoft, padding: const EdgeInsets.fromLTRB(14, 13, 14, 13), child: const Text('TQTO', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, letterSpacing: 1.4))),
          const SizedBox(height: 10),
          XiteraxNeoCard(child: Row(children: [
            _tqBox(Icons.code_rounded, '@rapwy', 'DEVELOPER', XiteraxColors.orange),
            const SizedBox(width: 10),
            _tqBox(Icons.verified_rounded, 'TEAM XITERAX', 'VERIFIED', XiteraxColors.blue),
          ])),
          const SizedBox(height: 16),
          _sectionTitle('XITERAX HUB', Icons.bolt_rounded),
          const SizedBox(height: 9),
          _hubCard(),
        ],
      ),
    );
  }

  Widget _heroCard() => XiteraxNeoCard(
    padding: EdgeInsets.zero,
    borderRadius: BorderRadius.circular(20),
    child: ClipRRect(
      borderRadius: BorderRadius.circular(17),
      child: Column(children: [
        SizedBox(height: 118, width: double.infinity, child: Stack(fit: StackFit.expand, children: [
          Image.asset('assets/images/xiterax_banner.jpg', fit: BoxFit.cover),
          const ColoredBox(color: Color(0x44000000)),
          const Positioned(left: 16, top: 15, child: Text('Ahlan Wa Sahlan', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900))),
          Positioned(right: 14, top: 13, child: Container(width: 38, height: 38, decoration: BoxDecoration(color: XiteraxColors.white, border: Border.all(color: XiteraxColors.black, width: 2), shape: BoxShape.circle), child: const Icon(Icons.check_rounded))),
        ])),
        Padding(padding: const EdgeInsets.all(13), child: Column(children: [
          Container(height: 2, color: XiteraxColors.black),
          const SizedBox(height: 12),
          Row(children: [
            _metric(Icons.person_rounded, '$onlineUsers', 'USER AKTIF', XiteraxColors.orange),
            _metric(FontAwesomeIcons.whatsapp, '$senderCount', 'SENDER', XiteraxColors.blue),
            _metric(Icons.battery_6_bar_rounded, '$deviceCount', 'DEVICE', XiteraxColors.surfaceSoft),
          ]),
          const SizedBox(height: 13),
          const Align(alignment: Alignment.centerLeft, child: Text('Design By Rapwy', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w800, color: XiteraxColors.greyDark))),
        ])),
      ]),
    ),
  );

  Widget _whatsappChooser() => XiteraxBackground(
    imageAsset: 'assets/images/xiterax_bug_background.jpg',
    child: ListView(
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 28),
      children: [
        _topTitle('WHATSAPP', subtitle: 'BUG & PAIRING'),
        const SizedBox(height: 12),
        XiteraxNeoCard(color: XiteraxColors.surfaceSoft, padding: const EdgeInsets.all(12), child: const Row(children: [Icon(Icons.explore_rounded, size: 22), SizedBox(width: 9), Expanded(child: Text('PILIH MODE PENGIRIMAN', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 11, letterSpacing: .8))), Icon(Icons.arrow_forward_rounded, size: 18)])),
        const SizedBox(height: 14),
        SizedBox(
          height: 410,
          child: PageView.builder(
            controller: _whatsappController,
            itemCount: 2,
            onPageChanged: (i) => setState(() => _whatsappIndex = i),
            itemBuilder: (_, i) => Padding(padding: const EdgeInsets.only(right: 12), child: _bugModeCard(i)),
          ),
        ),
        const SizedBox(height: 10),
        Center(
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: List.generate(2, (i) => AnimatedContainer(
              duration: const Duration(milliseconds: 220),
              margin: const EdgeInsets.symmetric(horizontal: 4),
              width: i == _whatsappIndex ? 34 : 9,
              height: 9,
              decoration: BoxDecoration(
                color: i == _whatsappIndex ? XiteraxColors.orange : XiteraxColors.black,
                border: Border.all(color: XiteraxColors.black, width: 1),
                borderRadius: BorderRadius.circular(20),
              ),
            )),
          ),
        ),
      ],
    ),
  );

  Widget _bugModeCard(int index) {
    final number = index == 0;
    final color = number ? XiteraxColors.blue : XiteraxColors.orange;
    return GestureDetector(
      onTap: () => _openBug(index),
      child: XiteraxNeoCard(
        padding: const EdgeInsets.fromLTRB(20, 26, 20, 22),
        borderRadius: BorderRadius.circular(24),
        color: XiteraxColors.white,
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Container(width: 88, height: 88, decoration: BoxDecoration(color: color, border: Border.all(color: XiteraxColors.black, width: 3), shape: BoxShape.circle, boxShadow: const [BoxShadow(color: XiteraxColors.black, offset: Offset(5, 6), blurRadius: 0)]), child: Icon(number ? Icons.bug_report_rounded : Icons.groups_rounded, size: 44, color: number ? XiteraxColors.white : XiteraxColors.black)),
          const SizedBox(height: 25),
          Container(padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8), decoration: BoxDecoration(color: XiteraxColors.surfaceSoft, border: Border.all(color: XiteraxColors.black, width: 2), borderRadius: BorderRadius.circular(11)), child: Text(number ? 'NUMBER' : 'GROUP', style: const TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1))),
          const SizedBox(height: 15),
          Text(number ? 'BUG NUMBER' : 'BUG GROUP', style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w900, letterSpacing: .6)),
          const SizedBox(height: 6),
          Text(number ? 'Kirim bug ke nomor WhatsApp' : 'Kirim bug ke link group WhatsApp', textAlign: TextAlign.center, style: const TextStyle(color: XiteraxColors.grey, fontSize: 13, fontWeight: FontWeight.w700)),
          const Spacer(),
          SizedBox(width: double.infinity, child: ElevatedButton.icon(onPressed: () => _openBug(index), icon: const Icon(Icons.arrow_forward_rounded), label: Text(number ? 'PILIH BUG NUMBER' : 'PILIH BUG GROUP'))),
        ]),
      ),
    );
  }

  Widget _metric(IconData icon, String value, String label, Color color) {
    final light = color == XiteraxColors.surfaceSoft;
    return Expanded(child: Container(margin: const EdgeInsets.symmetric(horizontal: 3), padding: const EdgeInsets.symmetric(vertical: 11, horizontal: 6), decoration: BoxDecoration(color: color, border: Border.all(color: XiteraxColors.black, width: 2), borderRadius: BorderRadius.circular(13)), child: Column(children: [Icon(icon, size: 20, color: light ? XiteraxColors.black : XiteraxColors.white), const SizedBox(height: 3), Text(value, style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900, color: light ? XiteraxColors.black : XiteraxColors.white)), Text(label, style: TextStyle(fontSize: 8, fontWeight: FontWeight.w900, color: light ? XiteraxColors.black : XiteraxColors.white))])));
  }

  Widget _sectionTitle(String text, IconData icon) => Row(children: [Container(width: 34, height: 34, decoration: BoxDecoration(color: XiteraxColors.orange, border: Border.all(color: XiteraxColors.black, width: 2), borderRadius: BorderRadius.circular(10)), child: Icon(icon, size: 18, color: XiteraxColors.black)), const SizedBox(width: 9), Text(text, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900, letterSpacing: 1.1))]);

  Widget _lockedSlider(List<(String, IconData, Color, VoidCallback)> items) => SizedBox(
    height: 102,
    child: PageView.builder(
      controller: _quickController,
      onPageChanged: (i) => setState(() => _quickIndex = i),
      itemCount: items.length,
      itemBuilder: (_, i) {
        final active = i == _quickIndex;
        return Padding(
          padding: const EdgeInsets.only(right: 10),
          child: GestureDetector(
            onTap: items[i].$4,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 220),
              decoration: BoxDecoration(
                color: active ? XiteraxColors.orange : XiteraxColors.white,
                border: Border.all(color: XiteraxColors.black, width: 2),
                borderRadius: BorderRadius.circular(16),
                boxShadow: const [BoxShadow(color: XiteraxColors.black, offset: Offset(4, 5), blurRadius: 0)],
              ),
              padding: const EdgeInsets.all(13),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(width: 40, height: 40, decoration: BoxDecoration(color: active ? XiteraxColors.white : items[i].$3, border: Border.all(color: XiteraxColors.black, width: 2), borderRadius: BorderRadius.circular(11)), child: Icon(items[i].$2, color: XiteraxColors.black)),
                  const SizedBox(height: 7),
                  Text(items[i].$1, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w900)),
                  const Text('GESER • PILIH • BUKA', style: TextStyle(fontSize: 8, fontWeight: FontWeight.w900, color: XiteraxColors.grey)),
                ],
              ),
            ),
          ),
        );
      },
    ),
  );

  Widget _hubCard() => XiteraxNeoCard(color: XiteraxColors.white, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    const Text('DAILY TOOLBOX', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900, letterSpacing: 1)),
    const SizedBox(height: 4),
    const Text('Empat akses cepat untuk aktivitas harian.', style: TextStyle(color: XiteraxColors.grey, fontWeight: FontWeight.w700, fontSize: 11)),
    const SizedBox(height: 12),
    Row(children: [
      _hubAction(Icons.music_note_rounded, 'SPOTIFY', XiteraxColors.orange, () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SpotifyPage()))),
      _hubAction(Icons.menu_book_rounded, 'QURAN', XiteraxColors.surfaceSoft, () => Navigator.push(context, MaterialPageRoute(builder: (_) => const QuranPage()))),
    ]),
    const SizedBox(height: 8),
    Row(children: [
      _hubAction(Icons.sports_esports_rounded, 'GAMES', XiteraxColors.blue, () => Navigator.push(context, MaterialPageRoute(builder: (_) => const GamesPage()))),
      _hubAction(Icons.calculate_rounded, 'CALC', XiteraxColors.surfaceSoft, () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CalculatorPage()))),
    ]),
    const SizedBox(height: 12),
    Container(width: double.infinity, padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8), decoration: BoxDecoration(color: XiteraxColors.black, borderRadius: BorderRadius.circular(10)), child: const Row(children: [Icon(Icons.auto_awesome_rounded, color: XiteraxColors.orange, size: 16), SizedBox(width: 7), Expanded(child: Text('XITERAX • DAILY UTILITY CENTER', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 9, letterSpacing: .8)))])),
  ]));

  Widget _hubAction(IconData icon, String title, Color color, VoidCallback onTap) => Expanded(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 3), child: GestureDetector(onTap: onTap, child: Container(padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8), decoration: BoxDecoration(color: color, border: Border.all(color: XiteraxColors.black, width: 2), borderRadius: BorderRadius.circular(12)), child: Row(children: [Icon(icon, size: 19), const SizedBox(width: 6), Text(title, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w900))])))));

  Widget _tqBox(IconData icon, String title, String sub, Color color) { final fg = color == XiteraxColors.blue ? XiteraxColors.white : XiteraxColors.black; return Expanded(child: Container(padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: color, border: Border.all(color: XiteraxColors.black, width: 2), borderRadius: BorderRadius.circular(14)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(icon, color: fg, size: 22), const SizedBox(height: 6), Text(title, style: TextStyle(color: fg, fontWeight: FontWeight.w900, fontSize: 12)), Text(sub, style: TextStyle(color: fg, fontWeight: FontWeight.w800, fontSize: 8))]))); }

  Widget _bottomBar() {
    const items = [
      (Icons.dashboard_rounded, 'DASHBOARD'),
      (FontAwesomeIcons.whatsapp, 'WHATSAPP'),
      (Icons.forum_rounded, 'CHAT GLOBAL'),
      (Icons.handyman_rounded, 'TOOLS'),
    ];
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 5, 12, 10),
        child: XiteraxNeoCard(
          padding: const EdgeInsets.all(5),
          borderRadius: BorderRadius.circular(18),
          child: Row(
            children: List.generate(items.length, (i) {
              final selected = _page == i;
              return Expanded(
                child: GestureDetector(
                  onTap: () => _go(i),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 240),
                    padding: const EdgeInsets.symmetric(vertical: 9),
                    margin: const EdgeInsets.symmetric(horizontal: 3),
                    decoration: BoxDecoration(color: selected ? XiteraxColors.black : Colors.transparent, borderRadius: BorderRadius.circular(13)),
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      Icon(items[i].$1, size: 20, color: selected ? XiteraxColors.white : XiteraxColors.black),
                      const SizedBox(height: 2),
                      Text(items[i].$2, style: TextStyle(fontSize: 8, fontWeight: FontWeight.w900, color: selected ? XiteraxColors.white : XiteraxColors.black)),
                    ]),
                  ),
                ),
              );
            }),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _onlineTimer?.cancel();
    _statsTimer?.cancel();
    _clockTimer?.cancel();
    _quickController.dispose();
    _whatsappController.dispose();
    try { _channel.sink.close(status.goingAway); } catch (_) {}
    _intro.dispose();
    super.dispose();
  }
}
