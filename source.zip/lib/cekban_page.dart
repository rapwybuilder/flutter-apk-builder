import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'app_config.dart';
import 'xiterax_theme.dart';
import 'package:http/http.dart' as http;

class CekBanPage extends StatefulWidget {
  final String sessionKey;
  const CekBanPage({super.key, required this.sessionKey});
  @override
  State<CekBanPage> createState() => _CekBanPageState();
}

class _CekBanPageState extends State<CekBanPage> {
  final _numberController = TextEditingController();
  bool _loading = false;
  Map<String, dynamic>? _result;
  String? _error;

  @override
  void dispose() { _numberController.dispose(); super.dispose(); }

  Future<void> _check() async {
    var number = _numberController.text.replaceAll(RegExp(r'[^0-9]'), '');
    if (number.startsWith('08')) number = '62${number.substring(1)}';
    if (number.length < 8 || number.length > 15) {
      setState(() => _error = 'Nomor tidak valid. Gunakan format 628xxxxxxxxxx.');
      return;
    }
    FocusManager.instance.primaryFocus?.unfocus();
    setState(() { _loading = true; _error = null; _result = null; });
    try {
      final uri = Uri.parse('$apiBaseUrl/cekban').replace(queryParameters: {'key': widget.sessionKey, 'number': number});
      final response = await http.get(uri).timeout(const Duration(seconds: 25));
      dynamic decoded;
      try { decoded = jsonDecode(response.body); } catch (_) { decoded = null; }
      if (response.statusCode >= 200 && response.statusCode < 300 && decoded is Map) {
        setState(() => _result = Map<String, dynamic>.from(decoded));
      } else {
        final message = decoded is Map ? (decoded['message'] ?? decoded['error'])?.toString() : null;
        setState(() => _error = message?.isNotEmpty == true ? message! : 'Server CEKBAN mengembalikan error (${response.statusCode}).');
      }
    } catch (e) {
      setState(() => _error = 'Tidak bisa terhubung ke API. Pastikan API aktif dan credential CEKBAN sudah dipasang.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Widget _row(String label, dynamic value, {bool mono = false}) {
    final text = (value == null || value.toString().trim().isEmpty) ? '-' : value.toString();
    return Container(
      margin: const EdgeInsets.only(bottom: 8), padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
      decoration: BoxDecoration(color: XiteraxColors.surfaceRaised, borderRadius: BorderRadius.circular(10), border: Border.all(color: XiteraxColors.divider)),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        SizedBox(width: 112, child: Text(label, style: const TextStyle(color: XiteraxColors.grey, fontSize: 11, fontWeight: FontWeight.w800))),
        Expanded(child: SelectableText(text, style: TextStyle(color: XiteraxColors.white, fontSize: 12, fontWeight: FontWeight.w800, fontFamily: mono ? 'ShareTechMono' : 'Baloo2'))),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    final banned = _result?['banned'] == true;
    final cooldowns = _result?['cooldowns'] is Map ? Map<String, dynamic>.from(_result!['cooldowns']) : <String, dynamic>{};
    final appeal = _result?['appeal_token']?.toString() ?? '';
    return Scaffold(
      backgroundColor: XiteraxColors.background,
      appBar: AppBar(title: const Text('CEKBAN'), leading: const BackButton()),
      body: XiteraxBackground(child: ListView(padding: const EdgeInsets.fromLTRB(16, 12, 16, 30), children: [
        Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: XiteraxColors.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: XiteraxColors.divider)), child: Row(children: [
          Container(width: 48, height: 48, decoration: BoxDecoration(color: XiteraxColors.orange, borderRadius: BorderRadius.circular(11)), child: const Icon(Icons.verified_user_rounded, color: XiteraxColors.black)),
          const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('WHATSAPP CHECK', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900)), const SizedBox(height: 2), Text('Status, cooldown, alasan dan Appeal Token.', style: TextStyle(color: XiteraxColors.grey, fontSize: 11))])),
        ])),
        const SizedBox(height: 14),
        TextField(controller: _numberController, keyboardType: TextInputType.phone, onSubmitted: (_) => _check(), decoration: const InputDecoration(labelText: 'Nomor WhatsApp', hintText: '628xxxxxxxxxx', prefixIcon: Icon(Icons.phone_rounded))),
        const SizedBox(height: 10),
        ElevatedButton.icon(onPressed: _loading ? null : _check, icon: _loading ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: XiteraxColors.black)) : const Icon(Icons.search_rounded), label: Text(_loading ? 'CHECKING...' : 'CHECK STATUS')),
        if (_error != null) ...[
          const SizedBox(height: 14),
          Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: const Color(0xFF27171A), borderRadius: BorderRadius.circular(12), border: Border.all(color: XiteraxColors.red)), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [const Icon(Icons.error_outline_rounded, color: XiteraxColors.red), const SizedBox(width: 10), Expanded(child: Text(_error!, style: const TextStyle(color: XiteraxColors.white, fontWeight: FontWeight.w700)))])),
        ],
        if (_result != null) ...[
          const SizedBox(height: 18),
          Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: banned ? const Color(0xFF35191B) : const Color(0xFF13291F), borderRadius: BorderRadius.circular(14), border: Border.all(color: banned ? XiteraxColors.red : XiteraxColors.green, width: 1.5)), child: Row(children: [Icon(banned ? Icons.block_rounded : Icons.check_circle_rounded, color: banned ? XiteraxColors.red : XiteraxColors.green), const SizedBox(width: 10), Text(banned ? 'BANNED / BLOCKED' : 'NOT BANNED', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900))])),
          const SizedBox(height: 12),
          _row('Number', _result!['number'], mono: true),
          _row('OTP Ready', _result!['otp_ready']),
          _row('WA Clone', _result!['wa_clone']),
          _row('Status', _result!['status']),
          _row('Reason', _result!['reason']),
          _row('Violation', _result!['violation_type']),
          if (appeal.isNotEmpty) ...[
            const SizedBox(height: 4),
            const Text('APPEAL TOKEN', style: TextStyle(color: XiteraxColors.orange, fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 1.4)),
            const SizedBox(height: 7),
            Container(padding: const EdgeInsets.all(13), decoration: BoxDecoration(color: XiteraxColors.surface, borderRadius: BorderRadius.circular(11), border: Border.all(color: XiteraxColors.orange)), child: Row(children: [Expanded(child: SelectableText(appeal, style: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 12, fontWeight: FontWeight.w800))), IconButton(tooltip: 'Copy', icon: const Icon(Icons.copy_rounded, size: 18), onPressed: () { Clipboard.setData(ClipboardData(text: appeal)); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Appeal Token disalin.'))); })])),
          ],
          if (cooldowns.isNotEmpty) ...[
            const SizedBox(height: 16), const Text('COOLDOWNS', style: TextStyle(color: XiteraxColors.orange, fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 1.4)), const SizedBox(height: 7),
            ...cooldowns.entries.map((e) => _row(e.key, e.value)),
          ],
        ],
      ])),
    );
  }
}
