import 'dart:math';
import 'package:flutter/material.dart';
import 'xiterax_theme.dart';

class GamesPage extends StatefulWidget {
  const GamesPage({super.key});
  @override State<GamesPage> createState() => _GamesPageState();
}

class _GamesPageState extends State<GamesPage> {
  int tab = 0;
  List<String> board = List.filled(9, '');
  bool xTurn = true;
  int scoreX = 0, scoreO = 0;
  int target = 1, attempts = 0;
  String guessMsg = 'Pilih angka 1–20';
  final rng = Random();

  @override void initState() { super.initState(); _newGuess(); }
  void _resetTtt() => setState(() { board = List.filled(9, ''); xTurn = true; });
  String? _winner() {
    for (final l in const [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]]) {
      if (board[l[0]].isNotEmpty && board[l[0]] == board[l[1]] && board[l[1]] == board[l[2]]) return board[l[0]];
    }
    return board.every((e) => e.isNotEmpty) ? 'DRAW' : null;
  }
  void _move(int i) {
    if (board[i].isNotEmpty || _winner() != null) return;
    final mark = xTurn ? 'X' : 'O';
    setState(() { board[i] = mark; xTurn = !xTurn; });
    final w = _winner();
    if (w != null) setState(() { if (w == 'X') scoreX++; if (w == 'O') scoreO++; });
  }
  void _newGuess() { setState(() { target = rng.nextInt(20) + 1; attempts = 0; guessMsg = 'Pilih angka 1–20'; }); }
  void _guess(int n) {
    if (n == target) {
      setState(() { attempts++; guessMsg = 'BENAR!'; target = -1; });
    } else {
      setState(() { attempts++; guessMsg = n < target ? 'Lebih BESAR' : 'Lebih KECIL'; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: XiteraxColors.background,
      appBar: AppBar(title: const Text('XITERAX GAMES')),
      body: ListView(padding: const EdgeInsets.fromLTRB(14, 8, 14, 28), children: [
        XiteraxNeoCard(color: XiteraxColors.orange, child: const Row(children: [Icon(Icons.sports_esports_rounded, size: 30), SizedBox(width: 10), Expanded(child: Text('MINI GAMES • PLAY & RELAX', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)))])),
        const SizedBox(height: 12),
        Row(children: [Expanded(child: _tab('TIC TAC TOE', 0, Icons.grid_3x3_rounded)), const SizedBox(width: 8), Expanded(child: _tab('GUESS', 1, Icons.psychology_rounded))]),
        const SizedBox(height: 12),
        tab == 0 ? _ttt() : _guessGame(),
      ]),
    );
  }

  Widget _tab(String title, int index, IconData icon) => GestureDetector(
    onTap: () => setState(() => tab = index),
    child: XiteraxNeoCard(color: tab == index ? XiteraxColors.black : XiteraxColors.white, padding: const EdgeInsets.symmetric(vertical: 11), child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(icon, color: tab == index ? Colors.white : Colors.black, size: 18), const SizedBox(width: 6), Text(title, style: TextStyle(color: tab == index ? Colors.white : Colors.black, fontWeight: FontWeight.w900, fontSize: 11))])),
  );

  Widget _ttt() => XiteraxNeoCard(child: Column(children: [
    Row(children: [const Expanded(child: Text('TIC TAC TOE', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900))), Text('X $scoreX  •  O $scoreO', style: const TextStyle(fontWeight: FontWeight.w900))]),
    const SizedBox(height: 12),
    GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: 9,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, crossAxisSpacing: 7, mainAxisSpacing: 7),
      itemBuilder: (_, i) => GestureDetector(
        onTap: () => _move(i),
        child: Container(
          decoration: BoxDecoration(color: board[i].isEmpty ? XiteraxColors.surfaceSoft : XiteraxColors.white, border: Border.all(color: XiteraxColors.black, width: 2), borderRadius: BorderRadius.circular(12)),
          child: Center(child: Text(board[i], style: TextStyle(fontSize: 35, fontWeight: FontWeight.w900, color: board[i] == 'X' ? XiteraxColors.blue : XiteraxColors.orange))),
        ),
      ),
    ),
    const SizedBox(height: 12),
    Text(_winner() == null ? 'Giliran ${xTurn ? 'X' : 'O'}' : (_winner() == 'DRAW' ? 'SERI!' : 'PEMENANG ${_winner()}'), style: const TextStyle(fontWeight: FontWeight.w900)),
    const SizedBox(height: 10),
    ElevatedButton.icon(onPressed: _resetTtt, icon: const Icon(Icons.refresh_rounded), label: const Text('MAIN LAGI')),
  ]));

  Widget _guessGame() => XiteraxNeoCard(child: Column(children: [
    const Icon(Icons.psychology_rounded, size: 60),
    const SizedBox(height: 8),
    const Text('TEBAK ANGKA', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
    const SizedBox(height: 5),
    Text(guessMsg, style: const TextStyle(color: XiteraxColors.grey, fontWeight: FontWeight.w800)),
    const SizedBox(height: 5),
    Text('Percobaan: $attempts', style: const TextStyle(fontWeight: FontWeight.w900)),
    const SizedBox(height: 14),
    if (target != -1) _guessButtons(),
    if (target == -1) const XiteraxNeoCard(color: XiteraxColors.blue, child: Text('Tebakan tepat. Mulai ronde baru untuk bermain lagi.', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900))),
    const SizedBox(height: 12),
    OutlinedButton.icon(onPressed: _newGuess, icon: const Icon(Icons.refresh_rounded), label: const Text('ANGKA BARU')),
  ]));

  Widget _guessButtons() => Wrap(
    spacing: 7,
    runSpacing: 7,
    children: List.generate(20, (i) => SizedBox(
      width: 52,
      height: 45,
      child: OutlinedButton(onPressed: () => _guess(i + 1), child: Text('${i + 1}', style: const TextStyle(fontWeight: FontWeight.w900))),
    )),
  );

}
