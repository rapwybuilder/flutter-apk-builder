import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'xiterax_theme.dart';

class XiteraxAiPage extends StatefulWidget {
  const XiteraxAiPage({super.key});

  @override
  State<XiteraxAiPage> createState() => _SpongebobAiPageState();
}

class _SpongebobAiPageState extends State<XiteraxAiPage> {
  static const String _endpoint = 'https://openrouter.ai/api/v1/chat/completions';
  // Keys are kept private in the source; for production, proxy requests through your backend.
  static const List<String> _apiKeys = [
    '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',
    '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',
  ];
  static const String _model = 'openrouter/auto';
  static const String _systemPrompt = '''You are a playful fictional cartoon-style AI companion inside the XITERAX app. Reply in Indonesian unless the user uses another language. Be energetic, friendly, useful and reasonably concise. Do not claim to be a real copyrighted character.''';

  final TextEditingController _controller = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final List<_ChatItem> _messages = [];
  bool _sending = false;
  int _keyIndex = 0;
  http.Client? _client;

  @override
  void initState() {
    super.initState();
    _messages.add(_ChatItem(false, 'Hai! Aku teman AI XITERAX. Mau ngobrol atau minta bantuan?'));
  }

  @override
  void dispose() {
    _client?.close();
    _controller.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    final text = _controller.text.trim();
    if (text.isEmpty || _sending) return;
    _controller.clear();

    setState(() {
      _messages.add(_ChatItem(true, text));
      _messages.add(_ChatItem(false, ''));
      _sending = true;
    });
    _scrollToBottom();

    try {
      final history = <Map<String, String>>[
        {'role': 'system', 'content': _systemPrompt},
        ..._messages
            .take(_messages.length - 1)
            .map((m) => {'role': m.mine ? 'user' : 'assistant', 'content': m.text}),
      ];

      String? answer;
      String? lastError;
      for (int i = 0; i < _apiKeys.length && answer == null; i++) {
        final idx = (_keyIndex + i) % _apiKeys.length;
        try {
          answer = await _streamWithKey(idx, history);
          if (answer.trim().isNotEmpty) {
            _keyIndex = idx;
            break;
          }
          answer = null;
        } catch (e) {
          lastError = e.toString();
          answer = null;
        }
      }

      if (!mounted) return;
      final fallback = 'AI belum merespons. Coba kirim lagi sebentar. ${lastError ?? ''}'.trim();
      setState(() {
        _messages.last.text = (answer == null || answer!.trim().isEmpty) ? fallback : answer!;
        _sending = false;
      });
      _scrollToBottom();
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _messages.last.text = 'Terjadi masalah koneksi. Coba kirim lagi.';
        _sending = false;
      });
    }
  }

  Future<String> _streamWithKey(int keyIndex, List<Map<String, String>> history) async {
    _client?.close();
    final client = http.Client();
    _client = client;
    final request = http.Request('POST', Uri.parse(_endpoint))
      ..headers.addAll({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ${_apiKeys[keyIndex]}',
        'HTTP-Referer': 'https://xiterax.app',
        'X-Title': 'XITERAX AI',
      })
      ..body = jsonEncode({
        'model': _model,
        'messages': history,
        'temperature': 0.7,
        'stream': true,
      });

    final response = await client.send(request).timeout(const Duration(seconds: 22));
    if (response.statusCode < 200 || response.statusCode >= 300) {
      final body = await response.stream.bytesToString();
      throw Exception('HTTP ${response.statusCode}: ${body.substring(0, body.length > 180 ? 180 : body.length)}');
    }

    final buffer = StringBuffer();
    var pending = '';
    await for (final chunk in response.stream.transform(utf8.decoder)) {
      pending += chunk;
      final lines = pending.split('\n');
      pending = lines.removeLast();
      for (final raw in lines) {
        final line = raw.trim();
        if (!line.startsWith('data:')) continue;
        final payload = line.substring(5).trim();
        if (payload == '[DONE]') continue;
        try {
          final data = jsonDecode(payload) as Map<String, dynamic>;
          final delta = data['choices']?[0]?['delta']?['content'];
          if (delta is String && delta.isNotEmpty) {
            buffer.write(delta);
            if (mounted) {
              setState(() => _messages.last.text = buffer.toString());
              _scrollToBottom();
            }
          }
        } catch (_) {
          // Ignore malformed/incomplete SSE fragments.
        }
      }
    }
    return buffer.toString();
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 180),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: XiteraxColors.background,
      body: XiteraxBackground(
        
        child: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 10, 12, 6),
                child: XiteraxNeoCard(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
                  child: Row(children: [
                    Container(width: 42, height: 42, decoration: BoxDecoration(color: XiteraxColors.orange, border: Border.all(color: XiteraxColors.black, width: 2), borderRadius: BorderRadius.circular(12)), child: const Icon(Icons.smart_toy_rounded)),
                    const SizedBox(width: 10),
                    const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('XITERAX AI', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)), Text('TOOLS • AI ASSISTANT', style: TextStyle(color: XiteraxColors.greyDark, fontSize: 8, letterSpacing: 1.2, fontWeight: FontWeight.w800))])),
                    IconButton(onPressed: () => Navigator.of(context).pop(), icon: const Icon(Icons.close_rounded)),
                  ]),
                ),
              ),
              Expanded(
                child: ListView.builder(
                  controller: _scrollController,
                  padding: const EdgeInsets.fromLTRB(12, 10, 12, 14),
                  itemCount: _messages.length,
                  itemBuilder: (_, index) {
                    final m = _messages[index];
                    final typing = _sending && index == _messages.length - 1 && !m.mine && m.text.isEmpty;
                    return Align(
                      alignment: m.mine ? Alignment.centerRight : Alignment.centerLeft,
                      child: Container(
                        constraints: const BoxConstraints(maxWidth: 340),
                        margin: const EdgeInsets.only(bottom: 10),
                        padding: const EdgeInsets.fromLTRB(13, 11, 13, 11),
                        decoration: BoxDecoration(
                          color: m.mine ? XiteraxColors.orange : XiteraxColors.white,
                          borderRadius: BorderRadius.circular(15),
                          border: Border.all(color: XiteraxColors.black, width: 2),
                          boxShadow: const [BoxShadow(color: XiteraxColors.black, offset: Offset(3, 4), blurRadius: 0)],
                        ),
                        child: typing ? const _TypingBubble() : Text(m.text, style: const TextStyle(color: XiteraxColors.black, fontSize: 14, height: 1.4, fontWeight: FontWeight.w700)),
                      ),
                    );
                  },
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 6, 12, 12),
                child: XiteraxNeoCard(
                  padding: const EdgeInsets.all(8),
                  child: Row(children: [
                    Expanded(child: TextField(controller: _controller, enabled: !_sending, textInputAction: TextInputAction.send, onSubmitted: (_) => _send(), decoration: const InputDecoration(hintText: 'Tulis pesan...', border: InputBorder.none, enabledBorder: InputBorder.none, focusedBorder: InputBorder.none))),
                    const SizedBox(width: 6),
                    GestureDetector(onTap: _sending ? null : _send, child: Container(width: 48, height: 48, decoration: BoxDecoration(color: XiteraxColors.orange, border: Border.all(color: XiteraxColors.black, width: 2), borderRadius: BorderRadius.circular(13)), child: const Icon(Icons.arrow_upward_rounded))),
                  ]),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ChatItem {
  final bool mine;
  String text;
  _ChatItem(this.mine, this.text);
}

class _TypingBubble extends StatefulWidget {
  const _TypingBubble();

  @override
  State<_TypingBubble> createState() => _TypingBubbleState();
}

class _TypingBubbleState extends State<_TypingBubble>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (_, __) {
        final active = (_controller.value * 3).floor();
        return Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('AI sedang mengetik', style: TextStyle(color: XiteraxColors.grey, fontSize: 12, fontWeight: FontWeight.w700)),
            const SizedBox(width: 6),
            for (var i = 0; i < 3; i++)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 2),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 120),
                  width: i == active ? 7 : 5,
                  height: i == active ? 7 : 5,
                  decoration: BoxDecoration(color: i == active ? XiteraxColors.orange : XiteraxColors.greyDark, shape: BoxShape.circle),
                ),
              ),
          ],
        );
      },
    );
  }
}

/// Backward-compatible alias for older routes.
class SpongebobAiPage extends XiteraxAiPage { const SpongebobAiPage({super.key}); }
