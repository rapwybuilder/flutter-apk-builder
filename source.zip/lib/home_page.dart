import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import 'app_config.dart';
import 'bug_sender.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'xiterax_theme.dart';

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;
  final int? initialMode;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
    this.initialMode,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final targetController = TextEditingController();
  late final AnimationController _progressController;
  late final AnimationController _entryController;
  late final PageController _payloadController;

  int payloadIndex = 0;
  int modeIndex = 0;
  String senderType = 'private';
  String selectedBugId = '';
  int globalSenderCount = 0;
  bool loadingSenders = false;
  bool isSending = false;
  int progress = 0;
  String? resultTitle;
  String? resultTarget;
  String? resultSender;
  String? cooldown;

  bool get canGlobal {
    final role = widget.role.trim().toLowerCase();
    return role == 'owner' || role == 'developer';
  }

  bool get isDeveloper => widget.role.trim().toLowerCase() == 'developer';

  List<Map<String, dynamic>> get visibleBugs {
    return widget.listBug.where((bug) {
      final raw = '${bug['bug_id'] ?? ''} ${bug['id'] ?? ''} ${bug['name'] ?? ''} ${bug['bug_name'] ?? ''} ${bug['title'] ?? ''}'.toUpperCase();
      final group = raw.contains('BAN GB') || RegExp(r'\bGB\b').hasMatch(raw);
      return modeIndex == 1 ? group : !group;
    }).toList();
  }

  @override
  void initState() {
    super.initState();
    modeIndex = widget.initialMode ?? 0;
    _payloadController = PageController(viewportFraction: .84);
    _progressController = AnimationController(vsync: this, duration: const Duration(seconds: 30));
    _entryController = AnimationController(vsync: this, duration: const Duration(milliseconds: 520))..forward();
    _resetPayloadForMode();
    _fetchSenders();
  }

  @override
  void dispose() {
    targetController.dispose();
    _progressController.dispose();
    _entryController.dispose();
    _payloadController.dispose();
    super.dispose();
  }

  void _resetPayloadForMode() {
    payloadIndex = 0;
    final bugs = visibleBugs;
    selectedBugId = bugs.isEmpty ? '' : '${bugs.first['bug_id'] ?? bugs.first['id'] ?? ''}';
    if (_payloadController.hasClients) {
      _payloadController.jumpToPage(0);
    }
  }

  void _setMode(int index) {
    if (isSending || index == modeIndex) return;
    setState(() {
      modeIndex = index;
      targetController.clear();
      resultTitle = null;
      resultTarget = null;
      resultSender = null;
      cooldown = null;
    });
    _resetPayloadForMode();
  }

  Future<void> _fetchSenders() async {
    if (mounted) setState(() => loadingSenders = true);
    try {
      final response = await http.get(Uri.parse('$apiBaseUrl/mySender?key=${widget.sessionKey}')).timeout(const Duration(seconds: 10));
      final data = jsonDecode(response.body);
      if (response.statusCode == 200 && data['valid'] == true && mounted) {
        final count = int.tryParse('${data['globalCount']}') ??
            (data['globalConnections'] is List ? (data['globalConnections'] as List).length : 0);
        setState(() => globalSenderCount = count);
      }
    } catch (_) {
      if (mounted) setState(() => globalSenderCount = 0);
    } finally {
      if (mounted) setState(() => loadingSenders = false);
    }
  }

  String? _phone(String value) {
    final clean = value.replaceAll(RegExp(r'[^\d+]'), '');
    return clean.startsWith('+') && clean.length >= 8 ? clean : null;
  }

  bool _groupLink(String value) => RegExp(r'^https://chat\.whatsapp\.com/[A-Za-z0-9_-]+/?$').hasMatch(value);

  Future<void> _sendBug() async {
    if (isSending) return;
    final target = targetController.text.trim();

    if (modeIndex == 0) {
      if (_phone(target) == null) {
        _dialog('NOMOR TIDAK VALID', 'Gunakan format internasional, contoh +628xxxxxxxxxx.');
        return;
      }
    } else if (!_groupLink(target)) {
      _dialog('LINK GROUP TIDAK VALID', 'Gunakan link WhatsApp group yang valid.');
      return;
    }

    if (selectedBugId.isEmpty) {
      _dialog('PAYLOAD BELUM TERSEDIA', modeIndex == 1 ? 'Payload group harus memakai menu GB atau BAN GB.' : 'Pilih payload nomor terlebih dahulu.');
      return;
    }

    if (senderType == 'global' && (!canGlobal || globalSenderCount == 0)) {
      _dialog('GLOBAL TIDAK TERSEDIA', canGlobal ? 'Belum ada global sender yang online.' : 'Sender global hanya untuk owner dan developer.');
      return;
    }

    setState(() {
      isSending = true;
      progress = 1;
      resultTitle = null;
      resultTarget = null;
      resultSender = null;
      cooldown = null;
    });

    _progressController.reset();
    void progressListener() {
      if (!mounted || !isSending) return;
      final value = (_progressController.value * 94).floor() + 1;
      if (value > progress) setState(() => progress = value.clamp(1, 95).toInt());
    }
    _progressController.addListener(progressListener);
    _progressController.forward();

    try {
      final uri = Uri.parse(
        '$apiBaseUrl/sendBug?key=${Uri.encodeQueryComponent(widget.sessionKey)}&target=${Uri.encodeQueryComponent(target)}&bug=${Uri.encodeQueryComponent(selectedBugId)}&senderType=$senderType',
      );
      final response = await http.get(uri).timeout(const Duration(seconds: 30));
      final data = jsonDecode(response.body);
      if (!mounted) return;

      if (data['cooldown'] == true) {
        final wait = data['wait'];
        final message = wait == null ? 'COOLDOWN' : 'COOLDOWN ${wait}s';
        setState(() {
          progress = 100;
          cooldown = message;
        });
        await _showStatus(message, Icons.schedule_rounded, XiteraxColors.orange);
      } else if (data['valid'] == false) {
        await _showStatus('SESSION INVALID', Icons.lock_rounded, XiteraxColors.orange);
      } else if (data['sended'] == false) {
        await _showStatus('${data['message'] ?? 'SEND FAILED'}', Icons.close_rounded, XiteraxColors.orange);
      } else {
        setState(() {
          progress = 100;
          resultTitle = 'SUCCESS SEND BUG';
          resultTarget = target;
          resultSender = senderType == 'global' ? 'SENDER GLOBAL' : 'SENDER PRIVATE';
        });
        await _showStatus('SUCCESS SEND BUG', Icons.check_rounded, XiteraxColors.blue);
        targetController.clear();
        if (senderType == 'global') _fetchSenders();
      }
    } catch (_) {
      if (mounted) await _showStatus('CONNECTION FAILED', Icons.wifi_off_rounded, XiteraxColors.orange);
    } finally {
      _progressController.stop();
      _progressController.removeListener(progressListener);
      if (mounted) setState(() => isSending = false);
    }
  }

  Future<void> _showStatus(String title, IconData icon, Color accent) async {
    await showDialog<void>(
      context: context,
      barrierDismissible: true,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 24),
        child: XiteraxNeoCard(
          padding: const EdgeInsets.fromLTRB(20, 22, 20, 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 88,
                height: 88,
                decoration: BoxDecoration(
                  color: accent,
                  shape: BoxShape.circle,
                  border: Border.all(color: XiteraxColors.black, width: 3),
                  boxShadow: const [BoxShadow(color: XiteraxColors.black, offset: Offset(4, 5), blurRadius: 0)],
                ),
                child: Icon(icon, size: 44, color: accent == XiteraxColors.orange ? XiteraxColors.black : XiteraxColors.white),
              ),
              const SizedBox(height: 16),
              Text(title, textAlign: TextAlign.center, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: XiteraxColors.black)),
              if (resultTarget != null) ...[
                const SizedBox(height: 8),
                Text(resultTarget!, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w900, color: XiteraxColors.black)),
                const SizedBox(height: 3),
                Text(resultSender ?? '', style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: XiteraxColors.greyDark)),
              ],
              if (title.startsWith('COOLDOWN')) ...[
                const SizedBox(height: 7),
                Text(isDeveloper && senderType == 'global' ? 'DEVELOPER • ∞' : title, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w900, color: XiteraxColors.greyDark)),
              ],
              const SizedBox(height: 17),
              SizedBox(width: double.infinity, child: ElevatedButton(onPressed: () => Navigator.pop(context), child: const Text('TUTUP'))),
            ],
          ),
        ),
      ),
    );
  }

  void _dialog(String title, String message) {
    showDialog<void>(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 24),
        child: XiteraxNeoCard(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: XiteraxColors.black)),
              const SizedBox(height: 8),
              Text(message, style: const TextStyle(fontSize: 12, height: 1.4, fontWeight: FontWeight.w700, color: XiteraxColors.greyDark)),
              const SizedBox(height: 16),
              SizedBox(width: double.infinity, child: ElevatedButton(onPressed: () => Navigator.pop(context), child: const Text('MENGERTI'))),
            ],
          ),
        ),
      ),
    );
  }

  void _openProfile() {
    Navigator.push(context, MaterialPageRoute(builder: (_) => ProfilePage(
      username: widget.username,
      password: widget.password,
      role: widget.role,
      expiredDate: widget.expiredDate,
      sessionKey: widget.sessionKey,
    )));
  }

  Future<void> _logout() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: XiteraxColors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
          side: const BorderSide(color: XiteraxColors.black, width: 2),
        ),
        title: const Text('LOGOUT?', style: TextStyle(fontWeight: FontWeight.w900)),
        content: const Text('Hapus sesi login dari perangkat ini?', style: TextStyle(fontWeight: FontWeight.w600)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('BATAL')),
          ElevatedButton.icon(onPressed: () => Navigator.pop(dialogContext, true), icon: const Icon(Icons.logout_rounded), label: const Text('LOGOUT')),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('username');
    await prefs.remove('password');
    await prefs.remove('key');
    if (!mounted) return;
    Navigator.of(context).pushNamedAndRemoveUntil('/login', (route) => false);
  }

  void _openMenu() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: XiteraxNeoCard(
            padding: const EdgeInsets.all(14),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _menuItem(Icons.person_rounded, 'PROFILE', _openProfile),
                const SizedBox(height: 8),
                _menuItem(Icons.phone_android_rounded, 'SENDER WHATSAPP', () {
                  Navigator.pop(context);
                  Navigator.push(context, MaterialPageRoute(builder: (_) => BugSenderPage(sessionKey: widget.sessionKey, username: widget.username, role: widget.role)));
                }),
                const SizedBox(height: 8),
                _menuItem(Icons.history_rounded, 'RIWAYAT PENGIRIMAN', () {
                  Navigator.pop(context);
                  Navigator.push(context, MaterialPageRoute(builder: (_) => RiwayatPage(sessionKey: widget.sessionKey, role: widget.role)));
                }),
                const SizedBox(height: 8),
                _menuItem(Icons.logout_rounded, 'LOGOUT', _logout),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _menuItem(IconData icon, String label, VoidCallback onTap) => SizedBox(
        width: double.infinity,
        child: OutlinedButton.icon(onPressed: onTap, icon: Icon(icon), label: Text(label)),
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: XiteraxColors.background,
      body: Stack(
        children: [
          Positioned.fill(
            child: Stack(
              fit: StackFit.expand,
              children: [
                Image.asset('assets/images/xiterax_bug_background.jpg', fit: BoxFit.cover),
                const ColoredBox(color: Color(0xE8F4F4F0)),
              ],
            ),
          ),
          SafeArea(
            child: AnimatedBuilder(
              animation: _entryController,
              builder: (_, child) => Transform.translate(
                offset: Offset(0, 12 * (1 - _entryController.value)),
                child: Opacity(opacity: _entryController.value, child: child),
              ),
              child: ListView(
                padding: const EdgeInsets.fromLTRB(12, 10, 12, 26),
                children: [
                  _header(),
                  const SizedBox(height: 10),
                  _banner(),
                  const SizedBox(height: 12),
                  _modeTabs(),
                  const SizedBox(height: 12),
                  _targetField(),
                  const SizedBox(height: 12),
                  _payloadSlider(),
                  const SizedBox(height: 12),
                  _senderSelector(),
                  const SizedBox(height: 12),
                  _sendPanel(),
                  if (resultTitle != null) ...[
                    const SizedBox(height: 12),
                    _resultCard(),
                  ],
                ],
              ),
            ),
          ),
          if (isSending) _sendingOverlay(),
        ],
      ),
    );
  }

  Widget _header() => Container(
        padding: const EdgeInsets.fromLTRB(10, 9, 10, 9),
        decoration: BoxDecoration(
          color: XiteraxColors.white,
          border: Border.all(color: XiteraxColors.black, width: 2.6),
          borderRadius: BorderRadius.circular(14),
          boxShadow: const [BoxShadow(color: XiteraxColors.black, offset: Offset(6, 7), blurRadius: 0)],
        ),
        child: Row(
          children: [
            _headerIcon(Icons.arrow_back_rounded, () => Navigator.pop(context), XiteraxColors.surfaceSoft),
            const SizedBox(width: 10),
            Container(width: 38, height: 38, decoration: BoxDecoration(color: XiteraxColors.black, borderRadius: BorderRadius.circular(10), border: Border.all(color: XiteraxColors.black, width: 2)), child: const Icon(Icons.bolt_rounded, color: XiteraxColors.white, size: 20)),
            const SizedBox(width: 9),
            const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('XITERAX', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, letterSpacing: 2)), Text('BUG CONTROL PANEL', style: TextStyle(fontSize: 7.5, fontWeight: FontWeight.w900, color: XiteraxColors.greyDark, letterSpacing: 1.1))])),
            _headerIcon(Icons.menu_rounded, _openMenu, XiteraxColors.orange),
            const SizedBox(width: 6),
            _headerIcon(Icons.person_rounded, _openProfile, XiteraxColors.blue),
          ],
        ),
      );

  Widget _headerIcon(IconData icon, VoidCallback onTap, Color color) => GestureDetector(
        onTap: onTap,
        child: Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: color,
            border: Border.all(color: XiteraxColors.black, width: 2),
            borderRadius: BorderRadius.circular(11),
            boxShadow: const [BoxShadow(color: XiteraxColors.black, offset: Offset(2, 3), blurRadius: 0)],
          ),
          child: Icon(icon, color: color == XiteraxColors.blue ? XiteraxColors.white : XiteraxColors.black, size: 20),
        ),
      );

  Widget _banner() => XiteraxNeoCard(
        padding: EdgeInsets.zero,
        borderRadius: BorderRadius.circular(17),
        child: SizedBox(
          height: 94,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(14),
            child: Stack(
              fit: StackFit.expand,
              children: [
                Image.asset('assets/images/xiterax_banner.jpg', fit: BoxFit.cover),
                const ColoredBox(color: Color(0x55000000)),
                Positioned(
                  left: 14,
                  bottom: 13,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(color: XiteraxColors.white, border: Border.all(color: XiteraxColors.black, width: 2), borderRadius: BorderRadius.circular(8)),
                        child: Text(modeIndex == 0 ? 'BUG NUMBER' : 'BUG GROUP', style: const TextStyle(fontSize: 8, fontWeight: FontWeight.w900)),
                      ),
                      const SizedBox(height: 5),
                      const Text('SEND CONTROL', style: TextStyle(color: XiteraxColors.white, fontSize: 18, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      );

  Widget _modeTabs() => XiteraxNeoCard(
        padding: const EdgeInsets.all(7),
        borderRadius: BorderRadius.circular(15),
        child: Row(
          children: [
            Expanded(child: _modeButton(0, Icons.phone_android_rounded, 'BUG NUMBER', 'NOMOR TARGET')),
            const SizedBox(width: 7),
            Expanded(child: _modeButton(1, Icons.groups_rounded, 'BUG GROUP', 'LINK GROUP')),
          ],
        ),
      );

  Widget _modeButton(int index, IconData icon, String title, String subtitle) {
    final selected = modeIndex == index;
    final accent = index == 0 ? XiteraxColors.orange : XiteraxColors.blue;
    return GestureDetector(
      onTap: () => _setMode(index),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        curve: Curves.easeOutCubic,
        height: 72,
        padding: const EdgeInsets.symmetric(horizontal: 11),
        decoration: BoxDecoration(
          color: selected ? accent : XiteraxColors.surfaceSoft,
          border: Border.all(color: XiteraxColors.black, width: selected ? 2.8 : 2),
          borderRadius: BorderRadius.circular(11),
          boxShadow: selected ? const [BoxShadow(color: XiteraxColors.black, offset: Offset(3, 4), blurRadius: 0)] : null,
        ),
        child: Row(children: [
          Container(width: 40, height: 40, decoration: BoxDecoration(color: XiteraxColors.black, borderRadius: BorderRadius.circular(10)), child: Icon(icon, color: XiteraxColors.white, size: 20)),
          const SizedBox(width: 9),
          Expanded(child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.w900, color: XiteraxColors.black, letterSpacing: .35)),
            const SizedBox(height: 2),
            Text(subtitle, style: const TextStyle(fontSize: 7.5, fontWeight: FontWeight.w800, color: XiteraxColors.greyDark)),
          ])),
          if (selected) const Icon(Icons.check_circle_rounded, size: 19, color: XiteraxColors.black),
        ]),
      ),
    );
  }

  Widget _targetField() => XiteraxNeoCard(
        padding: const EdgeInsets.fromLTRB(13, 13, 13, 13),
        borderRadius: BorderRadius.circular(15),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(width: 38, height: 38, decoration: BoxDecoration(color: XiteraxColors.black, borderRadius: BorderRadius.circular(10)), child: Icon(modeIndex == 0 ? Icons.phone_android_rounded : Icons.groups_rounded, color: XiteraxColors.white, size: 19)),
            const SizedBox(width: 9),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(modeIndex == 0 ? 'NOMOR TARGET' : 'LINK GROUP TARGET', style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w900, letterSpacing: .5)), Text(modeIndex == 0 ? 'Masukkan nomor tujuan' : 'Masukkan link group WhatsApp', style: const TextStyle(fontSize: 8.5, color: XiteraxColors.greyDark, fontWeight: FontWeight.w700))])),
            _smallBadge(modeIndex == 0 ? 'NUMBER' : 'GROUP', modeIndex == 0 ? XiteraxColors.orange : XiteraxColors.blue),
          ]),
          const SizedBox(height: 10),
          TextField(
            controller: targetController,
            keyboardType: modeIndex == 0 ? TextInputType.phone : TextInputType.url,
            style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900, color: XiteraxColors.black),
            cursorColor: XiteraxColors.blue,
            decoration: InputDecoration(
              prefixIcon: Icon(modeIndex == 0 ? Icons.phone_rounded : Icons.link_rounded, color: XiteraxColors.black),
              hintText: modeIndex == 0 ? '+628xxxxxxxxxx' : 'https://chat.whatsapp.com/...',
              hintStyle: const TextStyle(color: XiteraxColors.muted, fontWeight: FontWeight.w700, fontSize: 13),
              enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(11), borderSide: const BorderSide(color: XiteraxColors.black, width: 2.3)),
              focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(11), borderSide: const BorderSide(color: XiteraxColors.blue, width: 3)),
              filled: true, fillColor: XiteraxColors.white,
            ),
          ),
        ]),
      );

  Widget _payloadSlider() {
    final bugs = visibleBugs;
    final accent = modeIndex == 0 ? XiteraxColors.orange : XiteraxColors.blue;
    return XiteraxNeoCard(
      padding: const EdgeInsets.fromLTRB(12, 13, 12, 11),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(width: 36, height: 36, decoration: BoxDecoration(color: XiteraxColors.black, shape: BoxShape.circle, border: Border.all(color: XiteraxColors.black, width: 2)), child: const Icon(Icons.bug_report_rounded, color: XiteraxColors.white, size: 18)),
              const SizedBox(width: 9),
              const Expanded(child: Text('PILIH BUG PAYLOAD', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900, letterSpacing: .6))),
              _smallBadge('${bugs.isEmpty ? 0 : payloadIndex + 1} / ${bugs.length}', accent),
            ],
          ),
          const SizedBox(height: 10),
          SizedBox(
            height: 248,
            child: bugs.isEmpty
                ? _emptyPayload()
                : PageView.builder(
                    controller: _payloadController,
                    itemCount: bugs.length,
                    onPageChanged: (index) {
                      setState(() {
                        payloadIndex = index;
                        selectedBugId = '${bugs[index]['bug_id'] ?? bugs[index]['id'] ?? ''}';
                      });
                    },
                    itemBuilder: (_, index) => Padding(padding: const EdgeInsets.only(right: 10), child: _payloadCard(bugs[index], index == payloadIndex, index)),
                  ),
          ),
          const SizedBox(height: 7),
          Center(child: Text(modeIndex == 1 ? 'GB / BAN GB • GROUP PAYLOAD' : 'PAYLOAD NOMOR • TANPA GB', style: const TextStyle(fontSize: 9, fontWeight: FontWeight.w900, color: XiteraxColors.greyDark, letterSpacing: .7))),
        ],
      ),
    );
  }

  Widget _payloadCard(Map<String, dynamic> bug, bool selected, int index) {
    final id = '${bug['bug_id'] ?? bug['id'] ?? 'PAYLOAD-${index + 1}'}';
    final title = '${bug['name'] ?? bug['bug_name'] ?? bug['title'] ?? id}'.trim();
    final group = modeIndex == 1;
    final accent = group ? XiteraxColors.blue : XiteraxColors.orange;
    final bg = selected ? accent : XiteraxColors.white;
    final fg = selected ? XiteraxColors.white : XiteraxColors.black;

    return AnimatedContainer(
      duration: const Duration(milliseconds: 220),
      padding: const EdgeInsets.fromLTRB(16, 15, 16, 14),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(17),
        border: Border.all(color: XiteraxColors.black, width: selected ? 3 : 2),
        boxShadow: const [BoxShadow(color: XiteraxColors.black, offset: Offset(4, 5), blurRadius: 0)],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(width: 44, height: 44, decoration: BoxDecoration(color: XiteraxColors.white, shape: BoxShape.circle, border: Border.all(color: XiteraxColors.black, width: 2)), child: Icon(group ? Icons.groups_rounded : Icons.person_rounded, color: XiteraxColors.black, size: 22)),
              const SizedBox(width: 10),
              Expanded(child: Text(group ? 'BUG GROUP' : 'BUG NUMBER', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w900, color: fg, letterSpacing: .7))),
              if (selected) Container(width: 30, height: 30, decoration: BoxDecoration(color: XiteraxColors.white, shape: BoxShape.circle, border: Border.all(color: XiteraxColors.black, width: 2)), child: const Icon(Icons.check_rounded, size: 18)),
            ],
          ),
          const Spacer(),
          Text(title.toUpperCase(), maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 26, height: 1.0, fontWeight: FontWeight.w900, color: fg, letterSpacing: .2)),
          const SizedBox(height: 8),
          Text(id, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 10, fontWeight: FontWeight.w800, color: selected ? XiteraxColors.white : XiteraxColors.greyDark)),
          const SizedBox(height: 11),
          Row(children: [_smallBadge(group ? 'GB / BAN GB' : 'NUMBER', XiteraxColors.white, darkText: true), const Spacer(), Text(selected ? 'DIPILIH' : 'PILIH', style: TextStyle(fontSize: 9, fontWeight: FontWeight.w900, color: fg))]),
        ],
      ),
    );
  }

  Widget _emptyPayload() => Container(
        decoration: BoxDecoration(color: XiteraxColors.surfaceSoft, border: Border.all(color: XiteraxColors.black, width: 2), borderRadius: BorderRadius.circular(15)),
        child: Center(child: Padding(padding: const EdgeInsets.all(18), child: Column(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.inventory_2_outlined, size: 34), const SizedBox(height: 8), Text(modeIndex == 1 ? 'PAYLOAD GROUP TIDAK ADA' : 'PAYLOAD NOMOR TIDAK ADA', textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w900)), const SizedBox(height: 4), const Text('Data payload belum dikirim API.', textAlign: TextAlign.center, style: TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: XiteraxColors.greyDark))]))),
      );

  Widget _senderSelector() => XiteraxNeoCard(
        padding: const EdgeInsets.fromLTRB(12, 13, 12, 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [Container(width: 36, height: 36, decoration: BoxDecoration(color: XiteraxColors.black, shape: BoxShape.circle, border: Border.all(color: XiteraxColors.black, width: 2)), child: const Icon(Icons.swap_horiz_rounded, color: XiteraxColors.white, size: 19)), const SizedBox(width: 9), const Expanded(child: Text('PILIH SENDER', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900, letterSpacing: .6))), _smallBadge(loadingSenders ? 'CHECK...' : '$globalSenderCount GLOBAL', globalSenderCount > 0 ? XiteraxColors.blue : XiteraxColors.orange)]),
            const SizedBox(height: 10),
            Row(children: [Expanded(child: _senderCard('private', Icons.person_rounded, 'PRIVATE', 'UNLIMITED')), const SizedBox(width: 9), Expanded(child: _senderCard('global', Icons.public_rounded, 'GLOBAL', isDeveloper ? '∞ • DEVELOPER' : '3× / HARI'))]),
            const SizedBox(height: 8),
            Row(children: [const Icon(Icons.info_outline_rounded, size: 14, color: XiteraxColors.greyDark), const SizedBox(width: 5), Expanded(child: Text(senderType == 'global' ? 'GLOBAL memakai sender tertaut dan akses owner/developer.' : 'PRIVATE menggunakan sender private yang tersedia.', style: const TextStyle(fontSize: 9, fontWeight: FontWeight.w800, color: XiteraxColors.greyDark)))]),
          ],
        ),
      );

  Widget _senderCard(String value, IconData icon, String title, String subtitle) {
    final selected = senderType == value;
    final locked = value == 'global' && !canGlobal;
    final offline = value == 'global' && globalSenderCount == 0;
    final accent = value == 'global' ? XiteraxColors.blue : XiteraxColors.orange;

    return GestureDetector(
      onTap: locked ? null : () => setState(() => senderType = value),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.fromLTRB(11, 12, 11, 12),
        decoration: BoxDecoration(
          color: locked ? XiteraxColors.surfaceSoft : selected ? accent : XiteraxColors.white,
          border: Border.all(color: XiteraxColors.black, width: selected ? 3 : 2),
          borderRadius: BorderRadius.circular(14),
          boxShadow: selected ? const [BoxShadow(color: XiteraxColors.black, offset: Offset(3, 4), blurRadius: 0)] : null,
        ),
        child: Row(
          children: [
            Container(width: 34, height: 34, decoration: BoxDecoration(color: XiteraxColors.black, shape: BoxShape.circle), child: Icon(locked ? Icons.lock_rounded : icon, color: XiteraxColors.white, size: 17)),
            const SizedBox(width: 8),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w900, color: locked ? XiteraxColors.greyDark : selected ? XiteraxColors.black : XiteraxColors.black)), const SizedBox(height: 2), Text(locked ? 'OWNER / DEVELOPER' : offline ? 'OFFLINE • 0' : subtitle, style: TextStyle(fontSize: 8, fontWeight: FontWeight.w800, color: locked ? XiteraxColors.grey : selected ? XiteraxColors.black : XiteraxColors.greyDark))])),
            if (value == 'global') Container(width: 10, height: 10, decoration: BoxDecoration(color: offline ? XiteraxColors.orange : XiteraxColors.blue, shape: BoxShape.circle, border: Border.all(color: XiteraxColors.black, width: 1))),
          ],
        ),
      ),
    );
  }

  Widget _sendPanel() => XiteraxNeoCard(
        color: XiteraxColors.black,
        borderRadius: BorderRadius.circular(15),
        padding: const EdgeInsets.fromLTRB(12, 12, 12, 13),
        child: Column(
          children: [
            Row(children: [const Icon(Icons.send_rounded, color: XiteraxColors.white, size: 20), const SizedBox(width: 8), const Expanded(child: Text('READY TO SEND', style: TextStyle(color: XiteraxColors.white, fontSize: 12, fontWeight: FontWeight.w900, letterSpacing: 1))), _smallBadge(modeIndex == 0 ? 'NUMBER' : 'GROUP', modeIndex == 0 ? XiteraxColors.orange : XiteraxColors.blue, darkText: false)]),
            const SizedBox(height: 10),
            SizedBox(width: double.infinity, child: ElevatedButton.icon(onPressed: isSending ? null : _sendBug, icon: const Icon(Icons.rocket_launch_rounded), label: Text(modeIndex == 0 ? 'KIRIM BUG NUMBER' : 'KIRIM BUG GROUP'))),
          ],
        ),
      );

  Widget _resultCard() => XiteraxNeoCard(
        color: XiteraxColors.black,
        child: Column(children: [Container(width: 62, height: 62, decoration: BoxDecoration(color: XiteraxColors.blue, shape: BoxShape.circle, border: Border.all(color: XiteraxColors.white, width: 2)), child: const Icon(Icons.check_rounded, size: 36, color: XiteraxColors.white)), const SizedBox(height: 7), const Text('SUCCESS SEND BUG', style: TextStyle(color: XiteraxColors.white, fontSize: 19, fontWeight: FontWeight.w900)), const SizedBox(height: 6), Text(resultTarget ?? '', textAlign: TextAlign.center, style: const TextStyle(color: XiteraxColors.white, fontWeight: FontWeight.w900)), const SizedBox(height: 2), Text(resultSender ?? '', style: const TextStyle(color: XiteraxColors.white, fontSize: 10, fontWeight: FontWeight.w800))]),
      );

  Widget _sendingOverlay() => Positioned.fill(
        child: ColoredBox(
          color: const Color(0xB3000000),
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(22),
              child: XiteraxNeoCard(
                padding: const EdgeInsets.fromLTRB(22, 24, 22, 22),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    SizedBox(width: 104, height: 104, child: Stack(alignment: Alignment.center, children: [CircularProgressIndicator(value: progress / 100, strokeWidth: 8, backgroundColor: XiteraxColors.surfaceSoft, color: XiteraxColors.blue), Text('$progress%', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900))])),
                    const SizedBox(height: 15),
                    Text(modeIndex == 0 ? 'MENGIRIM BUG NUMBER' : 'MENGIRIM BUG GROUP', textAlign: TextAlign.center, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 4),
                    const Text('Tunggu sampai proses selesai.', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: XiteraxColors.greyDark)),
                  ],
                ),
              ),
            ),
          ),
        ),
      );

  Widget _smallBadge(String text, Color color, {bool darkText = true}) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
        decoration: BoxDecoration(color: color, border: Border.all(color: XiteraxColors.black, width: 1.5), borderRadius: BorderRadius.circular(8)),
        child: Text(text, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 8, fontWeight: FontWeight.w900, color: darkText ? XiteraxColors.black : XiteraxColors.white)),
      );
}
