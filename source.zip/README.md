# XITERAX UI Rework

Rework based on the supplied dashboard and landing references.

- XITERAX branding applied to the visible landing/dashboard/tools UI.
- Landing layout follows the supplied second reference: large logo, feature row, info card, primary/secondary buttons and socials.
- Dashboard layout follows the supplied first reference: blue top bar, large hero card, hanging AI character, status card, account/VPS card and horizontal Quick Access.
- Sponge AI character is anchored inside the hero card so it no longer gets covered by unrelated header buttons.
- Sponge AI uses streamed OpenRouter responses with a visible animated typing indicator and shorter request timeout.
- Global background image is retained across the app; legacy opaque page backdrops were made transparent/semi-transparent where appropriate so the image can show through.
- Tools page was fully restyled to the same XITERAX visual system.
- Primary buttons/cards can be opaque while secondary surfaces remain semi-transparent.
- No glow or drop shadows added.
- Existing navigation and feature entry points are retained.
- API base URL remains `http://node.felix-private.web.id:4797`.

Flutter SDK was not installed in the working environment, so this archive was checked statically rather than compiled here.

## API endpoint
`http://node.felix-private.web.id:4797`
