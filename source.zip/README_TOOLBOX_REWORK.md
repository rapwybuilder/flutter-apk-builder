# XITERAX Toolbox Rework

- Removed Comic and IQC from the Tools surface and project references.
- Added Spotify Play with XITERAX Soft Neo-Brutalism UI.
- Added Al-Quran reader using live Al Quran Cloud API.
- Added local Calculator.
- Added local Games: Tic Tac Toe and Guess Number.
- Expanded Tools with AI, Spotify, Quran, Games, Calculator, Weather, Sholat, QR, Anime, TikTok, Instagram, Shortlink, Phone Lookup and Domain Check.
- Dashboard bottom section changed from Comic preview to DAILY TOOLBOX / XITERAX HUB.
- Existing dashboard navigation, profile, logout, WhatsApp, global chat and sender functions are kept.
- No new package dependency was added.
