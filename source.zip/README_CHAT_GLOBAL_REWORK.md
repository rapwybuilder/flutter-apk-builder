# XITERAX — CHAT GLOBAL REWORK

Perubahan pada V7:
- CHAT GLOBAL dikembalikan ke navigasi utama.
- CHAT GLOBAL tersedia sebagai tab bottom navigation, Quick Access, dan menu hamburger.
- UI chat dibuat ulang dengan Soft Neo-Brutalism yang mengikuti theme XITERAX: putih, hitam, abu-abu, orange, biru; tanpa gradient/glow.
- Menambahkan header GLOBAL LOUNGE, status online, bubble pesan baru, composer baru, role badge, delete message, polling pesan, dan polling online user.
- Endpoint/API chat lama tetap dipakai: getPublicChat, sendPublicChat, deletePublicChat, getOnlineUsers.
- Tidak mengubah endpoint backend atau fungsi API chat.
