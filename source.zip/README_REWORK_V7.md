XITERAX V7 UI REWORK
- Full visual refresh of the shared Soft Neo-Brutalism system.
- Tighter proportions, less oversized cards, clearer hierarchy.
- Home/Bug: header, mode selector, target, large payload cards, sender, send panel, result/loading refined.
- Dashboard: reduced hero/chooser proportions and cleaner quick access sizing.
- Tools: AI/COMIC/IQC cards resized and unified.
- Landing: more compact hero and consistent corner geometry.
- Palette remains white/black/grey/orange/blue; no yellow UI, no gradients, no glow.
- Core API and navigation logic preserved.
